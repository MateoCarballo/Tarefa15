-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS concesionario;
USE concesionario;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    tipo_usuario ENUM('ADMINISTRADOR', 'VENDEDOR', 'GESTOR') NOT NULL
);

-- Tabla de clientes
CREATE TABLE IF NOT EXISTS clientes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    dni VARCHAR(9) NOT NULL UNIQUE,
    telefono VARCHAR(15),
    email VARCHAR(100),
    direccion VARCHAR(200)
);

-- Tabla de vehículos
CREATE TABLE IF NOT EXISTS vehiculos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    año INT NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    estado ENUM('DISPONIBLE', 'RESERVADO', 'VENDIDO', 'EN_REVISION', 'BAJA') NOT NULL,
    color VARCHAR(30),
    matricula VARCHAR(10),
    kilometraje INT,
    garantia BOOLEAN DEFAULT FALSE
);

-- Tabla de ventas
CREATE TABLE IF NOT EXISTS ventas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    vehiculo_id BIGINT NOT NULL,
    cliente_id BIGINT NOT NULL,
    usuario_id BIGINT,
    fecha_venta DATETIME NOT NULL,
    precio_venta DECIMAL(10,2) NOT NULL,
    financiado BOOLEAN DEFAULT FALSE,
    entrada BOOLEAN DEFAULT FALSE,
    cantidad_entrada DECIMAL(10,2) DEFAULT 0,
    observaciones VARCHAR(500),
    FOREIGN KEY (vehiculo_id) REFERENCES vehiculos(id),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Insertar usuarios de prueba
INSERT INTO usuarios (username, password, nombre, apellidos, tipo_usuario) VALUES
('admin', 'admin123', 'Juan', 'García Administrador', 'ADMINISTRADOR'),
('vendedor1', 'vend123', 'María', 'López Vendedora', 'VENDEDOR'),
('vendedor2', 'vend456', 'Carlos', 'Martínez Ventas', 'VENDEDOR'),
('gestor1', 'gest123', 'Ana', 'Rodríguez Gestora', 'GESTOR');

-- Insertar clientes de prueba
INSERT INTO clientes (nombre, apellidos, dni, telefono, email, direccion) VALUES
('Pedro', 'Sánchez Comprador', '12345678A', '666111222', 'pedro@email.com', 'Calle Mayor 1, Madrid'),
('Laura', 'Fernández Cliente', '87654321B', '666333444', 'laura@email.com', 'Avenida Libertad 23, Barcelona'),
('Miguel', 'Torres Particular', '11223344C', '666555666', 'miguel@email.com', 'Plaza España 5, Valencia'),
('Carmen', 'Ruiz Compradora', '44556677D', '666777888', 'carmen@email.com', 'Calle Real 42, Sevilla');

-- Insertar vehículos de prueba
INSERT INTO vehiculos (marca, modelo, año, precio, estado, color, matricula, kilometraje, garantia) VALUES
('Volkswagen', 'Golf 8 TSI', 2023, 28500.00, 'DISPONIBLE', 'Blanco', '1234ABC', 0, TRUE),
('Toyota', 'Corolla Hybrid', 2023, 26900.00, 'DISPONIBLE', 'Gris Plata', '5678DEF', 10, TRUE),
('BMW', 'Serie 3 320d', 2022, 42000.00, 'RESERVADO', 'Negro', '9012GHI', 5000, TRUE),
('Mercedes-Benz', 'Clase A 180d', 2023, 35600.00, 'DISPONIBLE', 'Azul Marino', '3456JKL', 0, TRUE),
('Audi', 'A3 Sportback', 2022, 32800.00, 'VENDIDO', 'Rojo', '7890MNO', 12000, FALSE),
('Seat', 'León FR', 2023, 29700.00, 'DISPONIBLE', 'Gris Grafito', '1357PQR', 0, TRUE),
('Peugeot', '3008 GT', 2022, 36500.00, 'EN_REVISION', 'Blanco Nacarado', '2468STU', 8000, FALSE),
('Hyundai', 'Tucson Hybrid', 2023, 33900.00, 'DISPONIBLE', 'Verde Oscuro', '9876VWX', 0, TRUE);

-- Insertar ventas de prueba
INSERT INTO ventas (vehiculo_id, cliente_id, usuario_id, fecha_venta, precio_venta, financiado, entrada, cantidad_entrada, observaciones) VALUES
(5, 1, 2, '2024-01-15 10:30:00', 31500.00, TRUE, TRUE, 5000.00, 'Venta al contado. Cliente satisfecho con el precio.'),
(3, 2, 3, '2024-02-01 16:45:00', 41000.00, TRUE, FALSE, 0.00, 'Financiación a 60 meses. Incluye seguro a todo riesgo primer año.'),
(7, 3, 2, '2024-02-15 12:20:00', 35000.00, FALSE, TRUE, 10000.00, 'Descuento especial por pago en efectivo. Entrega inmediata.'); 