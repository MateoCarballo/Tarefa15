package com.concesionario.util;

import java.sql.*;

public class DatabaseTest {
    public static void main(String[] args) {
        try {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Intentar conectar
            System.out.println("Intentando conectar a la base de datos...");
            Connection conn = DatabaseConnection.getConnection();
            System.out.println("¡Conexión exitosa!");
            
            // Verificar datos en la tabla clientes
            System.out.println("\nVerificando tabla clientes:");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as total FROM clientes");
            if (rs.next()) {
                System.out.println("Total de clientes: " + rs.getInt("total"));
            }
            
            // Mostrar algunos clientes si existen
            rs = stmt.executeQuery("SELECT * FROM clientes LIMIT 3");
            while (rs.next()) {
                System.out.println("Cliente encontrado: " + 
                    rs.getString("nombre") + " " + 
                    rs.getString("apellidos") + " (DNI: " + 
                    rs.getString("dni") + ")");
            }
            
            // Verificar datos en la tabla ventas
            System.out.println("\nVerificando tabla ventas:");
            rs = stmt.executeQuery("SELECT COUNT(*) as total FROM ventas");
            if (rs.next()) {
                System.out.println("Total de ventas: " + rs.getInt("total"));
            }
            
            // Cerrar recursos
            rs.close();
            stmt.close();
            conn.close();
            
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se encontró el driver de MySQL");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error de SQL: " + e.getMessage());
            e.printStackTrace();
        }
    }
} 