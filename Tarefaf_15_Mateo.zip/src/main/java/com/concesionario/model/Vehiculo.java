package com.concesionario.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "vehiculos")
public class Vehiculo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String marca;

    @Column(nullable = false)
    private String modelo;

    @Column(nullable = false)
    private Integer año;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal precio;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EstadoVehiculo estado;

    @Column
    private String color;

    @Column
    private String matricula;

    @Column
    private Integer kilometraje;

    @OneToMany(mappedBy = "vehiculo")
    private List<Venta> ventas;

    public enum EstadoVehiculo {
        DISPONIBLE,
        RESERVADO,
        VENDIDO,
        EN_REVISION,
        BAJA
    }
} 