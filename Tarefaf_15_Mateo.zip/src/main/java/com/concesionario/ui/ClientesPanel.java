package com.concesionario.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.sql.SQLException;
import com.concesionario.model.Cliente;
import com.concesionario.dao.ClienteDAO;
import java.util.List;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.RowFilter;
import java.awt.event.ActionEvent;
import java.sql.*;
import com.concesionario.util.DatabaseConnection;

public class ClientesPanel extends JPanel {
    private JTable tablaClientes;
    private DefaultTableModel modeloTabla;
    private JTextField txtNombre;
    private JTextField txtApellidos;
    private JTextField txtDNI;
    private JTextField txtTelefono;
    private JTextField txtEmail;
    private JTextField txtDireccion;
    private JButton btnAgregar;
    private JButton btnModificar;
    private JButton btnEliminar;
    private JButton btnRefrescar;
    private JTextField txtFiltrar;
    private JToolBar toolBar;
    private ClienteDAO clienteDAO;
    private TableRowSorter<DefaultTableModel> sorter;
    private MainFrame mainFrame;

    public ClientesPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout(5, 5));
        clienteDAO = new ClienteDAO();
        initComponents();
        cargarDatosDeBaseDeDatos();
        setupLayout();
        setupListeners();
    }

    private void initComponents() {
        // Inicializar la barra de herramientas
        toolBar = new JToolBar();
        toolBar.setFloatable(false);
        
        // Botones de la barra de herramientas
        btnAgregar = new JButton("Agregar");
        btnModificar = new JButton("Modificar");
        btnEliminar = new JButton("Eliminar");
        btnRefrescar = new JButton("Refrescar");
        
        // Campo de filtrado
        txtFiltrar = new JTextField(20);
        txtFiltrar.setToolTipText("Filtrar clientes por nombre, apellidos o DNI");

        // Componentes del formulario
        txtNombre = new JTextField(20);
        txtApellidos = new JTextField(20);
        txtDNI = new JTextField(10);
        txtTelefono = new JTextField(15);
        txtEmail = new JTextField(20);
        txtDireccion = new JTextField(30);

        // Tabla de clientes
        String[] columnas = {"ID", "Nombre", "Apellidos", "DNI", "Teléfono", "Email", "Dirección"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaClientes = new JTable(modeloTabla);
        sorter = new TableRowSorter<>(modeloTabla);
        tablaClientes.setRowSorter(sorter);
        tablaClientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private void setupLayout() {
        // Configurar la barra de herramientas
        toolBar.add(btnAgregar);
        toolBar.add(btnModificar);
        toolBar.add(btnEliminar);
        toolBar.add(btnRefrescar);
        toolBar.addSeparator();
        toolBar.add(new JLabel("Filtrar: "));
        toolBar.add(txtFiltrar);
        add(toolBar, BorderLayout.NORTH);

        // Panel de formulario
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Primera fila
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtNombre, gbc);
        gbc.gridx = 2;
        formPanel.add(new JLabel("Apellidos:"), gbc);
        gbc.gridx = 3;
        formPanel.add(txtApellidos, gbc);

        // Segunda fila
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("DNI:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtDNI, gbc);
        gbc.gridx = 2;
        formPanel.add(new JLabel("Teléfono:"), gbc);
        gbc.gridx = 3;
        formPanel.add(txtTelefono, gbc);

        // Tercera fila
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtEmail, gbc);
        gbc.gridx = 2;
        formPanel.add(new JLabel("Dirección:"), gbc);
        gbc.gridx = 3;
        formPanel.add(txtDireccion, gbc);

        // Agregar el formulario y la tabla
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(tablaClientes), BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        btnAgregar.addActionListener(e -> agregarCliente());
        btnModificar.addActionListener(e -> modificarCliente());
        btnEliminar.addActionListener(e -> eliminarCliente());
        btnRefrescar.addActionListener(e -> cargarDatosDeBaseDeDatos());
        
        // Añadir listener para cargar datos en el formulario al seleccionar una fila
        tablaClientes.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int filaSeleccionada = tablaClientes.getSelectedRow();
                if (filaSeleccionada >= 0) {
                    cargarClienteEnFormulario(filaSeleccionada);
                }
            }
        });

        // Configurar el filtro
        txtFiltrar.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) { filtrar(); }
            public void removeUpdate(DocumentEvent e) { filtrar(); }
            public void insertUpdate(DocumentEvent e) { filtrar(); }
        });
        
        // Configurar accesibilidad
        configurarAccesibilidad();
    }

    private void configurarAccesibilidad() {
        // Configurar tooltips
        txtNombre.setToolTipText("Ingrese el nombre del cliente");
        txtApellidos.setToolTipText("Ingrese los apellidos del cliente");
        txtDNI.setToolTipText("Ingrese el DNI del cliente");
        txtTelefono.setToolTipText("Ingrese el teléfono del cliente");
        txtEmail.setToolTipText("Ingrese el email del cliente");
        txtDireccion.setToolTipText("Ingrese la dirección del cliente");

        // Configurar mnemonics
        btnAgregar.setMnemonic('A');
        btnModificar.setMnemonic('M');
        btnEliminar.setMnemonic('E');
        btnRefrescar.setMnemonic('R');

        // Configurar nombres accesibles
        txtNombre.getAccessibleContext().setAccessibleName("Campo de nombre");
        txtApellidos.getAccessibleContext().setAccessibleName("Campo de apellidos");
        txtDNI.getAccessibleContext().setAccessibleName("Campo de DNI");
        txtTelefono.getAccessibleContext().setAccessibleName("Campo de teléfono");
        txtEmail.getAccessibleContext().setAccessibleName("Campo de email");
        txtDireccion.getAccessibleContext().setAccessibleName("Campo de dirección");
    }

    private void cargarDatosDeBaseDeDatos() {
        try {
            System.out.println("Intentando cargar datos de clientes...");
            // Limpiar tabla
            modeloTabla.setRowCount(0);
            
            // Cargar datos
            List<Object[]> clientes = clienteDAO.obtenerTodosLosClientes();
            System.out.println("Clientes encontrados: " + clientes.size());
            
            for (Object[] cliente : clientes) {
                modeloTabla.addRow(cliente);
            }
            System.out.println("Datos cargados exitosamente en la tabla");
            
        } catch (SQLException e) {
            String mensaje = "Error al cargar los datos: " + e.getMessage() + 
                           "\nCódigo de error: " + e.getErrorCode() +
                           "\nEstado SQL: " + e.getSQLState();
            System.err.println(mensaje);
            e.printStackTrace();
            
            JOptionPane.showMessageDialog(this,
                mensaje,
                "Error de Base de Datos",
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            String mensaje = "Error inesperado: " + e.getMessage();
            System.err.println(mensaje);
            e.printStackTrace();
            
            JOptionPane.showMessageDialog(this,
                mensaje,
                "Error Inesperado",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregarCliente() {
        if (!validarCampos()) {
            return;
        }

        try {
            // Verificar si el DNI ya existe
            if (clienteDAO.existeDNI(txtDNI.getText(), null)) {
                JOptionPane.showMessageDialog(this,
                    "Ya existe un cliente con ese DNI",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            Cliente cliente = new Cliente();
            cliente.setNombre(txtNombre.getText());
            cliente.setApellidos(txtApellidos.getText());
            cliente.setDni(txtDNI.getText());
            cliente.setTelefono(txtTelefono.getText());
            cliente.setEmail(txtEmail.getText());
            cliente.setDireccion(txtDireccion.getText());

            clienteDAO.agregarCliente(cliente);
            cargarDatosDeBaseDeDatos();
            limpiarFormulario();
            JOptionPane.showMessageDialog(this,
                "Cliente agregado correctamente",
                "Éxito",
                JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error al agregar el cliente: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modificarCliente() {
        int filaSeleccionada = tablaClientes.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un cliente para modificar",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!validarCampos()) {
            return;
        }

        try {
            Long id = (Long) tablaClientes.getValueAt(filaSeleccionada, 0);
            
            // Verificar si el DNI ya existe (excluyendo el cliente actual)
            if (clienteDAO.existeDNI(txtDNI.getText(), id)) {
                JOptionPane.showMessageDialog(this,
                    "Ya existe otro cliente con ese DNI",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            Cliente cliente = new Cliente();
            cliente.setId(id);
            cliente.setNombre(txtNombre.getText());
            cliente.setApellidos(txtApellidos.getText());
            cliente.setDni(txtDNI.getText());
            cliente.setTelefono(txtTelefono.getText());
            cliente.setEmail(txtEmail.getText());
            cliente.setDireccion(txtDireccion.getText());

            clienteDAO.actualizarCliente(cliente);
            cargarDatosDeBaseDeDatos();
            limpiarFormulario();
            JOptionPane.showMessageDialog(this,
                "Cliente modificado correctamente",
                "Éxito",
                JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error al modificar el cliente: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarCliente() {
        int filaSeleccionada = tablaClientes.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un cliente para eliminar",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de que desea eliminar este cliente?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                Long id = (Long) tablaClientes.getValueAt(filaSeleccionada, 0);
                clienteDAO.eliminarCliente(id);
                cargarDatosDeBaseDeDatos();
                limpiarFormulario();
                JOptionPane.showMessageDialog(this,
                    "Cliente eliminado correctamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,
                    "Error al eliminar el cliente: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void cargarClienteEnFormulario(int fila) {
        if (fila >= 0) {
            txtNombre.setText((String) tablaClientes.getValueAt(fila, 1));
            txtApellidos.setText((String) tablaClientes.getValueAt(fila, 2));
            txtDNI.setText((String) tablaClientes.getValueAt(fila, 3));
            txtTelefono.setText((String) tablaClientes.getValueAt(fila, 4));
            txtEmail.setText((String) tablaClientes.getValueAt(fila, 5));
            txtDireccion.setText((String) tablaClientes.getValueAt(fila, 6));
        }
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtApellidos.setText("");
        txtDNI.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtDireccion.setText("");
        tablaClientes.clearSelection();
    }

    private boolean validarCampos() {
        if (txtNombre.getText().trim().isEmpty()) {
            mostrarError("El nombre es obligatorio");
            return false;
        }
        if (txtApellidos.getText().trim().isEmpty()) {
            mostrarError("Los apellidos son obligatorios");
            return false;
        }
        if (!validarDNI(txtDNI.getText())) {
            mostrarError("El DNI no es válido (formato: 12345678A)");
            return false;
        }
        if (!txtEmail.getText().trim().isEmpty() && !validarEmail(txtEmail.getText())) {
            mostrarError("El email no es válido");
            return false;
        }
        if (!txtTelefono.getText().trim().isEmpty() && !validarTelefono(txtTelefono.getText())) {
            mostrarError("El teléfono no es válido (9 dígitos)");
            return false;
        }
        return true;
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this,
            mensaje,
            "Error de validación",
            JOptionPane.ERROR_MESSAGE);
    }

    private boolean validarDNI(String dni) {
        return dni.matches("\\d{8}[A-Za-z]");
    }

    private boolean validarEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    private boolean validarTelefono(String telefono) {
        return telefono.matches("\\d{9}");
    }

    private void filtrar() {
        String texto = txtFiltrar.getText().toLowerCase();
        if (texto.trim().isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto, 1, 2, 3)); // Filtrar por nombre, apellidos y DNI
        }
    }
} 