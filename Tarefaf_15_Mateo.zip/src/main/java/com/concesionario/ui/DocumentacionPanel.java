package com.concesionario.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.URI;
import java.nio.file.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class DocumentacionPanel extends JPanel {
    private JButton btnAnalisis;
    private JButton btnManual;
    private JPanel panelBotones;
    private JPanel panelContenido;
    private static final String ANALISIS_PATH = "/docs/analisis_inicial.pdf";
    private static final String MANUAL_PATH = "/docs/manual_usuario.pdf";

    public DocumentacionPanel() {
        setLayout(new BorderLayout(10, 10));
        initComponents();
        setupLayout();
    }

    private void initComponents() {
        // Inicializar componentes
        btnAnalisis = new JButton("Ver Análisis Inicial");
        btnManual = new JButton("Ver Manual de Usuario");
        
        // Configurar el aspecto de los botones
        btnAnalisis.setFont(new Font("Arial", Font.BOLD, 14));
        btnAnalisis.setBackground(new Color(70, 130, 180));
        btnAnalisis.setForeground(Color.WHITE);
        btnAnalisis.setFocusPainted(false);
        btnAnalisis.addActionListener(e -> abrirAnalisis());
        
        btnManual.setFont(new Font("Arial", Font.BOLD, 14));
        btnManual.setBackground(new Color(60, 179, 113));
        btnManual.setForeground(Color.WHITE);
        btnManual.setFocusPainted(false);
        btnManual.addActionListener(e -> abrirManual());
        
        // Panel de botones
        panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Panel de contenido principal
        panelContenido = new JPanel(new BorderLayout());
        panelContenido.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Añadir una etiqueta descriptiva
        JLabel lblDescripcion = new JLabel("<html><div style='text-align: center;'>" +
            "<h2>Documentación del Sistema</h2>" +
            "<p>Esta sección permite acceder a la documentación del sistema:</p>" +
            "<ul>" +
            "<li><b>Análisis Inicial:</b> Documento que describe el análisis y diseño del sistema</li>" +
            "<li><b>Manual de Usuario:</b> Guía completa para el uso de la aplicación</li>" +
            "</ul>" +
            "</div></html>");
        lblDescripcion.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Añadir componentes a los paneles
        panelBotones.add(btnAnalisis);
        panelBotones.add(btnManual);
        panelContenido.add(lblDescripcion, BorderLayout.CENTER);
    }

    private void setupLayout() {
        add(panelContenido, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void abrirAnalisis() {
        try {
            abrirDocumento(ANALISIS_PATH, "Análisis Inicial");
        } catch (Exception ex) {
            mostrarError("Error al abrir el análisis inicial", ex);
        }
    }

    private void abrirManual() {
        try {
            abrirDocumento(MANUAL_PATH, "Manual de Usuario");
        } catch (Exception ex) {
            mostrarError("Error al abrir el manual de usuario", ex);
        }
    }

    private void abrirDocumento(String resourcePath, String titulo) throws IOException {
        // Primero intentar abrir desde los recursos
        try (InputStream is = getClass().getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new IOException("No se pudo encontrar el documento en: " + resourcePath);
            }

            // Crear archivo temporal
            Path tempFile = Files.createTempFile("concesionario_" + titulo.toLowerCase().replace(" ", "_"), ".pdf");
            Files.copy(is, tempFile, StandardCopyOption.REPLACE_EXISTING);

            // Abrir el archivo con el visor predeterminado del sistema
            Desktop.getDesktop().open(tempFile.toFile());

            // Registrar un gancho de apagado para eliminar el archivo temporal
            tempFile.toFile().deleteOnExit();
        }
    }

    private void mostrarError(String mensaje, Exception ex) {
        String mensajeCompleto = mensaje + ":\n" + ex.getMessage();
        if (ex.getCause() != null) {
            mensajeCompleto += "\nCausa: " + ex.getCause().getMessage();
        }
        JOptionPane.showMessageDialog(this,
            mensajeCompleto,
            "Error",
            JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }
} 