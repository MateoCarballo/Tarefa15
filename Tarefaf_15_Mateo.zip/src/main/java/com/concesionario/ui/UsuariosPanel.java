package com.concesionario.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import com.concesionario.model.Usuario;
import com.concesionario.model.Usuario.TipoUsuario;
import java.util.Vector;

public class UsuariosPanel extends JPanel {
    private JTable tablaUsuarios;
    private DefaultTableModel modeloTabla;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JTextField txtNombre;
    private JTextField txtApellidos;
    private JComboBox<TipoUsuario> cmbTipoUsuario;
    private JButton btnAgregar;
    private JButton btnModificar;
    private JButton btnEliminar;
    private JTextField txtBuscar;
    private JToolBar toolBar;

    public UsuariosPanel() {
        setLayout(new BorderLayout(5, 5));
        initComponents();
        setupLayout();
        setupListeners();
    }

    private void initComponents() {
        // Inicializar la barra de herramientas
        toolBar = new JToolBar();
        toolBar.setFloatable(false);
        
        // Botones de la barra de herramientas con íconos
        btnAgregar = new JButton("Agregar", new ImageIcon(getClass().getResource("/images/add.png")));
        btnModificar = new JButton("Modificar", new ImageIcon(getClass().getResource("/images/edit.png")));
        btnEliminar = new JButton("Eliminar", new ImageIcon(getClass().getResource("/images/delete.png")));
        
        // Campo de búsqueda
        txtBuscar = new JTextField(20);
        txtBuscar.setToolTipText("Buscar usuario por nombre o username");

        // Componentes del formulario
        txtUsername = new JTextField(20);
        txtPassword = new JPasswordField(20);
        txtNombre = new JTextField(20);
        txtApellidos = new JTextField(30);
        cmbTipoUsuario = new JComboBox<>(TipoUsuario.values());

        // Tabla de usuarios
        String[] columnas = {"ID", "Username", "Nombre", "Apellidos", "Tipo Usuario"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaUsuarios = new JTable(modeloTabla);
        tablaUsuarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private void setupLayout() {
        // Configurar la barra de herramientas
        toolBar.add(btnAgregar);
        toolBar.add(btnModificar);
        toolBar.add(btnEliminar);
        toolBar.addSeparator();
        toolBar.add(new JLabel("Buscar: "));
        toolBar.add(txtBuscar);
        add(toolBar, BorderLayout.NORTH);

        // Panel de formulario
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Primera fila
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtUsername, gbc);
        gbc.gridx = 2;
        formPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 3;
        formPanel.add(txtPassword, gbc);

        // Segunda fila
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtNombre, gbc);
        gbc.gridx = 2;
        formPanel.add(new JLabel("Apellidos:"), gbc);
        gbc.gridx = 3;
        formPanel.add(txtApellidos, gbc);

        // Tercera fila
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Tipo de Usuario:"), gbc);
        gbc.gridx = 1;
        formPanel.add(cmbTipoUsuario, gbc);

        // Agregar el formulario y la tabla
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(tablaUsuarios), BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        btnAgregar.addActionListener(this::agregarUsuario);
        btnModificar.addActionListener(this::modificarUsuario);
        btnEliminar.addActionListener(this::eliminarUsuario);
        txtBuscar.addActionListener(this::buscarUsuarios);
        
        // Configurar accesibilidad
        configurarAccesibilidad();
    }

    private void configurarAccesibilidad() {
        // Configurar tooltips
        txtUsername.setToolTipText("Ingrese el nombre de usuario");
        txtPassword.setToolTipText("Ingrese la contraseña");
        txtNombre.setToolTipText("Ingrese el nombre del usuario");
        txtApellidos.setToolTipText("Ingrese los apellidos del usuario");
        cmbTipoUsuario.setToolTipText("Seleccione el tipo de usuario");

        // Configurar mnemonics
        btnAgregar.setMnemonic('A');
        btnModificar.setMnemonic('M');
        btnEliminar.setMnemonic('E');

        // Configurar nombres accesibles
        txtUsername.getAccessibleContext().setAccessibleName("Campo de nombre de usuario");
        txtPassword.getAccessibleContext().setAccessibleName("Campo de contraseña");
        txtNombre.getAccessibleContext().setAccessibleName("Campo de nombre");
        txtApellidos.getAccessibleContext().setAccessibleName("Campo de apellidos");
        cmbTipoUsuario.getAccessibleContext().setAccessibleName("Selector de tipo de usuario");
    }

    private void agregarUsuario(ActionEvent e) {
        try {
            // Validar campos obligatorios
            if (txtUsername.getText().trim().isEmpty() || 
                new String(txtPassword.getPassword()).trim().isEmpty() ||
                txtNombre.getText().trim().isEmpty() || 
                txtApellidos.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Todos los campos son obligatorios",
                    "Error de validación",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Crear nuevo usuario
            Vector<Object> row = new Vector<>();
            row.add(modeloTabla.getRowCount() + 1); // ID temporal
            row.add(txtUsername.getText());
            row.add(txtNombre.getText());
            row.add(txtApellidos.getText());
            row.add(cmbTipoUsuario.getSelectedItem());

            modeloTabla.addRow(row);
            limpiarFormulario();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error al agregar el usuario: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modificarUsuario(ActionEvent e) {
        int selectedRow = tablaUsuarios.getSelectedRow();
        if (selectedRow >= 0) {
            // Implementar lógica de modificación
        } else {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un usuario para modificar",
                "Selección requerida",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void eliminarUsuario(ActionEvent e) {
        int selectedRow = tablaUsuarios.getSelectedRow();
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de que desea eliminar este usuario?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                modeloTabla.removeRow(selectedRow);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un usuario para eliminar",
                "Selección requerida",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void buscarUsuarios(ActionEvent e) {
        String busqueda = txtBuscar.getText().toLowerCase();
        // Implementar lógica de búsqueda
    }

    private void limpiarFormulario() {
        txtUsername.setText("");
        txtPassword.setText("");
        txtNombre.setText("");
        txtApellidos.setText("");
        cmbTipoUsuario.setSelectedIndex(0);
        txtUsername.requestFocus();
    }
} 