package com.concesionario.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import com.concesionario.model.Vehiculo;
import com.concesionario.model.Vehiculo.EstadoVehiculo;
import java.util.Vector;
import java.net.URL;
import com.concesionario.dao.VehiculoDAO;
import java.util.List;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.RowFilter;
import java.util.HashMap;
import java.util.Map;

public class VehiculosPanel extends JPanel {
    private JTable tablaVehiculos;
    private DefaultTableModel modeloTabla;
    private JTextField txtMarca;
    private JTextField txtModelo;
    private JSpinner spnAño;
    private JTextField txtPrecio;
    private ButtonGroup grupoEstados;
    private Map<String, JRadioButton> radioButtons;
    private JTextField txtColor;
    private JTextField txtMatricula;
    private JSpinner spnKilometraje;
    private JCheckBox chkGarantia;
    private JButton btnAgregar;
    private JButton btnModificar;
    private JButton btnEliminar;
    private JButton btnRefrescar;
    private JTextField txtFiltrar;
    private JToolBar toolBar;
    private VehiculoDAO vehiculoDAO;
    private TableRowSorter<DefaultTableModel> sorter;
    private MainFrame mainFrame;

    public VehiculosPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout(5, 5));
        vehiculoDAO = new VehiculoDAO();
        initComponents();
        cargarDatosDeBaseDeDatos();
        setupLayout();
        setupListeners();
    }

    private void initComponents() {
        // Inicializar la barra de herramientas
        toolBar = new JToolBar();
        toolBar.setFloatable(false);
        
        // Botones de la barra de herramientas (sin íconos temporalmente)
        btnAgregar = new JButton("Agregar");
        btnModificar = new JButton("Modificar");
        btnEliminar = new JButton("Eliminar");
        btnRefrescar = new JButton("Refrescar");
        
        // Campo de filtrado
        txtFiltrar = new JTextField(20);
        txtFiltrar.setToolTipText("Filtrar vehículos por marca, modelo o matrícula");

        // Componentes del formulario
        txtMarca = new JTextField(20);
        txtModelo = new JTextField(20);
        spnAño = new JSpinner(new SpinnerNumberModel(2024, 1900, 2024, 1));
        txtPrecio = new JTextField(10);
        
        // Configurar radio buttons para estados
        grupoEstados = new ButtonGroup();
        radioButtons = new HashMap<>();
        String[] estados = {"DISPONIBLE", "RESERVADO", "VENDIDO", "EN_REVISION", "BAJA"};
        
        for (String estado : estados) {
            JRadioButton radio = new JRadioButton(estado);
            radioButtons.put(estado, radio);
            grupoEstados.add(radio);
        }
        // Seleccionar DISPONIBLE por defecto
        radioButtons.get("DISPONIBLE").setSelected(true);
        
        // Checkbox de garantía
        chkGarantia = new JCheckBox("Garantía");
        chkGarantia.setToolTipText("Marcar si el vehículo tiene garantía vigente");
        
        txtColor = new JTextField(15);
        txtMatricula = new JTextField(10);
        spnKilometraje = new JSpinner(new SpinnerNumberModel(0, 0, 999999, 1000));

        // Tabla de vehículos
        String[] columnas = {"ID", "Marca", "Modelo", "Año", "Precio", "Estado", "Color", "Matrícula", "Kilometraje", "Garantía"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 9) { // Columna de Garantía
                    return Boolean.class;
                }
                return super.getColumnClass(columnIndex);
            }
        };
        tablaVehiculos = new JTable(modeloTabla);
        sorter = new TableRowSorter<>(modeloTabla);
        tablaVehiculos.setRowSorter(sorter);
        tablaVehiculos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Configurar el filtro
        txtFiltrar.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) { filtrar(); }
            public void removeUpdate(DocumentEvent e) { filtrar(); }
            public void insertUpdate(DocumentEvent e) { filtrar(); }
        });
    }

    private void setupLayout() {
        // Configurar la barra de herramientas
        toolBar.add(btnAgregar);
        toolBar.add(btnModificar);
        toolBar.add(btnEliminar);
        toolBar.add(btnRefrescar);
        toolBar.addSeparator();
        toolBar.add(new JLabel("Filtrar: "));
        toolBar.add(txtFiltrar);
        add(toolBar, BorderLayout.NORTH);

        // Panel de formulario
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Primera fila
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Marca:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtMarca, gbc);
        gbc.gridx = 2;
        formPanel.add(new JLabel("Modelo:"), gbc);
        gbc.gridx = 3;
        formPanel.add(txtModelo, gbc);

        // Segunda fila
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Año:"), gbc);
        gbc.gridx = 1;
        formPanel.add(spnAño, gbc);
        gbc.gridx = 2;
        formPanel.add(new JLabel("Precio:"), gbc);
        gbc.gridx = 3;
        formPanel.add(txtPrecio, gbc);

        // Tercera fila - Panel de estados y garantía
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Estado:"), gbc);
        
        // Panel para los radio buttons y checkbox
        JPanel estadosPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        for (JRadioButton radio : radioButtons.values()) {
            estadosPanel.add(radio);
        }
        estadosPanel.add(Box.createHorizontalStrut(20)); // Espacio entre estados y garantía
        estadosPanel.add(chkGarantia);
        
        gbc.gridx = 1;
        gbc.gridwidth = 3;
        formPanel.add(estadosPanel, gbc);
        gbc.gridwidth = 1;

        // Cuarta fila
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("Color:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtColor, gbc);
        gbc.gridx = 2;
        formPanel.add(new JLabel("Matrícula:"), gbc);
        gbc.gridx = 3;
        formPanel.add(txtMatricula, gbc);

        // Quinta fila
        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(new JLabel("Kilometraje:"), gbc);
        gbc.gridx = 1;
        formPanel.add(spnKilometraje, gbc);

        // Agregar el formulario y la tabla
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(tablaVehiculos), BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        btnAgregar.addActionListener(e -> agregarVehiculo());
        btnModificar.addActionListener(e -> modificarVehiculo());
        btnEliminar.addActionListener(e -> eliminarVehiculo());
        btnRefrescar.addActionListener(e -> cargarDatosDeBaseDeDatos());
        txtFiltrar.addActionListener(e -> buscarVehiculos());
        
        // Añadir listener para cargar datos en el formulario al seleccionar una fila
        tablaVehiculos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int filaSeleccionada = tablaVehiculos.getSelectedRow();
                if (filaSeleccionada >= 0) {
                    cargarVehiculoEnFormulario(filaSeleccionada);
                }
            }
        });
        
        // Configurar accesibilidad
        configurarAccesibilidad();
    }

    private void configurarAccesibilidad() {
        // Configurar tooltips
        txtMarca.setToolTipText("Ingrese la marca del vehículo");
        txtModelo.setToolTipText("Ingrese el modelo del vehículo");
        spnAño.setToolTipText("Seleccione el año del vehículo");
        txtPrecio.setToolTipText("Ingrese el precio del vehículo");
        txtColor.setToolTipText("Ingrese el color del vehículo");
        txtMatricula.setToolTipText("Ingrese la matrícula del vehículo");
        spnKilometraje.setToolTipText("Ingrese el kilometraje del vehículo");

        // Configurar mnemonics
        btnAgregar.setMnemonic('A');
        btnModificar.setMnemonic('M');
        btnEliminar.setMnemonic('E');
        btnRefrescar.setMnemonic('R');

        // Configurar nombres accesibles
        txtMarca.getAccessibleContext().setAccessibleName("Campo de marca");
        txtModelo.getAccessibleContext().setAccessibleName("Campo de modelo");
        spnAño.getAccessibleContext().setAccessibleName("Selector de año");
        txtPrecio.getAccessibleContext().setAccessibleName("Campo de precio");
    }

    private void cargarDatosDeBaseDeDatos() {
        // Limpiar tabla
        modeloTabla.setRowCount(0);
        
        // Cargar datos
        List<Object[]> vehiculos = vehiculoDAO.obtenerTodosLosVehiculos();
        for (Object[] vehiculo : vehiculos) {
            // Añadir false por defecto para la columna de garantía si no existe
            Object[] vehiculoConGarantia = new Object[10];
            System.arraycopy(vehiculo, 0, vehiculoConGarantia, 0, vehiculo.length);
            vehiculoConGarantia[9] = false; // Garantía por defecto
            modeloTabla.addRow(vehiculoConGarantia);
        }
    }

    private void agregarVehiculo() {
        // Confirmar agregación
        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de que desea agregar este vehículo?",
            "Confirmar agregación",
            JOptionPane.YES_NO_OPTION);

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            // Validar campos
            if (txtMarca.getText().trim().isEmpty() || 
                txtModelo.getText().trim().isEmpty() || 
                txtPrecio.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Los campos Marca, Modelo y Precio son obligatorios",
                    "Error de validación",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Procesar el precio: eliminar símbolos de moneda y convertir comas en puntos
            String precioTexto = txtPrecio.getText()
                .replace("€", "")
                .replace(".", "")  // Eliminar puntos de miles
                .replace(",", ".") // Convertir coma decimal en punto
                .trim();

            BigDecimal precio = new BigDecimal(precioTexto);
            
            // Crear nuevo vehículo
            Vector<Object> row = new Vector<>();
            row.add(modeloTabla.getRowCount() + 1); // ID temporal
            row.add(txtMarca.getText());
            row.add(txtModelo.getText());
            row.add(spnAño.getValue());
            row.add(String.format("%.2f €", precio)); // Formatear precio con símbolo de euro
            row.add(getSelectedEstado());
            row.add(txtColor.getText());
            row.add(txtMatricula.getText());
            row.add(spnKilometraje.getValue());
            row.add(chkGarantia.isSelected());

            modeloTabla.addRow(row);
            limpiarFormulario();

            // Después de guardar el vehículo exitosamente
            mainFrame.getStatusPanel().actualizarAhora();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error al agregar el vehículo: Verifique que el precio sea un número válido",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarVehiculoEnFormulario(int fila) {
        txtMarca.setText(modeloTabla.getValueAt(fila, 1).toString());
        txtModelo.setText(modeloTabla.getValueAt(fila, 2).toString());
        spnAño.setValue(Integer.parseInt(modeloTabla.getValueAt(fila, 3).toString()));
        
        // Obtener el precio y quitar el símbolo de euro y espacios
        String precioStr = modeloTabla.getValueAt(fila, 4).toString()
            .replace("€", "")
            .trim();
        txtPrecio.setText(precioStr);
        
        setSelectedEstado(modeloTabla.getValueAt(fila, 5).toString());
        txtColor.setText(modeloTabla.getValueAt(fila, 6).toString());
        txtMatricula.setText(modeloTabla.getValueAt(fila, 7).toString());
        spnKilometraje.setValue(Integer.parseInt(modeloTabla.getValueAt(fila, 8).toString()));
        
        // Manejar el valor de garantía de forma segura
        Object garantiaValue = modeloTabla.getValueAt(fila, 9);
        chkGarantia.setSelected(garantiaValue != null && (Boolean) garantiaValue);
    }

    private void modificarVehiculo() {
        int filaSeleccionada = tablaVehiculos.getSelectedRow();
        if (filaSeleccionada < 0) {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un vehículo para modificar",
                "Selección requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        filaSeleccionada = tablaVehiculos.convertRowIndexToModel(filaSeleccionada);
        int id = Integer.parseInt(modeloTabla.getValueAt(filaSeleccionada, 0).toString());

        // Obtener valores actuales de la tabla
        String marcaActual = modeloTabla.getValueAt(filaSeleccionada, 1).toString();
        String modeloActual = modeloTabla.getValueAt(filaSeleccionada, 2).toString();
        int añoActual = Integer.parseInt(modeloTabla.getValueAt(filaSeleccionada, 3).toString());
        double precioActual = Double.parseDouble(modeloTabla.getValueAt(filaSeleccionada, 4).toString()
            .replace(" €", "").replace(",", "."));
        String estadoActual = modeloTabla.getValueAt(filaSeleccionada, 5).toString();
        String colorActual = modeloTabla.getValueAt(filaSeleccionada, 6).toString();
        String matriculaActual = modeloTabla.getValueAt(filaSeleccionada, 7).toString();
        int kilometrajeActual = Integer.parseInt(modeloTabla.getValueAt(filaSeleccionada, 8).toString());
        
        // Manejar el valor de garantía de forma segura
        Object garantiaValue = modeloTabla.getValueAt(filaSeleccionada, 9);
        boolean garantiaActual = garantiaValue != null && (Boolean) garantiaValue;

        // Verificar qué campos han sido modificados
        boolean hayModificaciones = false;
        StringBuilder cambios = new StringBuilder("Se modificarán los siguientes campos:\n");

        String nuevaMarca = txtMarca.getText().trim();
        String nuevoModelo = txtModelo.getText().trim();
        int nuevoAño = (Integer) spnAño.getValue();
        String colorNuevo = txtColor.getText().trim();
        String matriculaNueva = txtMatricula.getText().trim();
        int nuevoKilometraje = (Integer) spnKilometraje.getValue();
        String nuevoEstado = getSelectedEstado();
        boolean nuevaGarantia = chkGarantia.isSelected();
        
        // Validar y obtener el nuevo precio
        double nuevoPrecio = precioActual;
        if (!txtPrecio.getText().trim().isEmpty()) {
            try {
                String precioStr = txtPrecio.getText().replace(" €", "").replace(",", ".");
                nuevoPrecio = Double.parseDouble(precioStr);
                if (nuevoPrecio <= 0) {
                    JOptionPane.showMessageDialog(this,
                        "El precio debe ser mayor que cero",
                        "Error de validación",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this,
                    "Por favor, ingrese un precio válido",
                    "Error de formato",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Comprobar cada campo modificado
        if (!nuevaMarca.isEmpty() && !nuevaMarca.equals(marcaActual)) {
            cambios.append("- Marca: ").append(marcaActual).append(" → ").append(nuevaMarca).append("\n");
            hayModificaciones = true;
        } else {
            nuevaMarca = marcaActual;
        }

        if (!nuevoModelo.isEmpty() && !nuevoModelo.equals(modeloActual)) {
            cambios.append("- Modelo: ").append(modeloActual).append(" → ").append(nuevoModelo).append("\n");
            hayModificaciones = true;
        } else {
            nuevoModelo = modeloActual;
        }

        if (nuevoAño != añoActual) {
            cambios.append("- Año: ").append(añoActual).append(" → ").append(nuevoAño).append("\n");
            hayModificaciones = true;
        }

        if (nuevoPrecio != precioActual) {
            cambios.append("- Precio: ").append(String.format("%.2f €", precioActual))
                   .append(" → ").append(String.format("%.2f €", nuevoPrecio)).append("\n");
            hayModificaciones = true;
        }

        if (!nuevoEstado.equals(estadoActual)) {
            cambios.append("- Estado: ").append(estadoActual).append(" → ").append(nuevoEstado).append("\n");
            hayModificaciones = true;
        }

        if (!colorNuevo.isEmpty() && !colorNuevo.equals(colorActual)) {
            cambios.append("- Color: ").append(colorActual).append(" → ").append(colorNuevo).append("\n");
            hayModificaciones = true;
        } else {
            colorNuevo = colorActual;
        }

        if (!matriculaNueva.isEmpty() && !matriculaNueva.equals(matriculaActual)) {
            cambios.append("- Matrícula: ").append(matriculaActual).append(" → ").append(matriculaNueva).append("\n");
            hayModificaciones = true;
        } else {
            matriculaNueva = matriculaActual;
        }

        if (nuevoKilometraje != kilometrajeActual) {
            cambios.append("- Kilometraje: ").append(kilometrajeActual).append(" → ").append(nuevoKilometraje).append("\n");
            hayModificaciones = true;
        }

        if (nuevaGarantia != garantiaActual) {
            cambios.append("- Garantía: ").append(garantiaActual ? "Sí" : "No")
                   .append(" → ").append(nuevaGarantia ? "Sí" : "No").append("\n");
            hayModificaciones = true;
        }

        if (!hayModificaciones) {
            JOptionPane.showMessageDialog(this,
                "No se han detectado cambios en ningún campo",
                "Sin modificaciones",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Confirmar modificación mostrando los cambios
        int confirmacion = JOptionPane.showConfirmDialog(this,
            cambios.toString() + "\n¿Desea continuar con la modificación?",
            "Confirmar modificación",
            JOptionPane.YES_NO_OPTION);

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            // Actualizar la tabla directamente
            modeloTabla.setValueAt(nuevaMarca, filaSeleccionada, 1);
            modeloTabla.setValueAt(nuevoModelo, filaSeleccionada, 2);
            modeloTabla.setValueAt(nuevoAño, filaSeleccionada, 3);
            modeloTabla.setValueAt(String.format("%.2f €", nuevoPrecio), filaSeleccionada, 4);
            modeloTabla.setValueAt(nuevoEstado, filaSeleccionada, 5);
            modeloTabla.setValueAt(colorNuevo, filaSeleccionada, 6);
            modeloTabla.setValueAt(matriculaNueva, filaSeleccionada, 7);
            modeloTabla.setValueAt(nuevoKilometraje, filaSeleccionada, 8);
            modeloTabla.setValueAt(nuevaGarantia, filaSeleccionada, 9);

            boolean exito = vehiculoDAO.actualizarVehiculo(
                id,
                nuevaMarca,
                nuevoModelo,
                nuevoAño,
                nuevoPrecio,
                nuevoEstado,
                colorNuevo,
                matriculaNueva,
                nuevoKilometraje
            );

            if (exito) {
                JOptionPane.showMessageDialog(this,
                    "Vehículo actualizado correctamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
                limpiarFormulario();

                // Después de actualizar el vehículo exitosamente
                mainFrame.getStatusPanel().actualizarAhora();
            } else {
                JOptionPane.showMessageDialog(this,
                    "No se pudo actualizar el vehículo",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error al modificar el vehículo: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarVehiculo() {
        int filaSeleccionada = tablaVehiculos.getSelectedRow();
        if (filaSeleccionada < 0) {
            JOptionPane.showMessageDialog(this,
                "Por favor, seleccione un vehículo para eliminar",
                "Selección requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Confirmar eliminación
        int confirmacion = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de que desea eliminar este vehículo?\nEsta acción no se puede deshacer.",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            filaSeleccionada = tablaVehiculos.convertRowIndexToModel(filaSeleccionada);
            int id = Integer.parseInt(modeloTabla.getValueAt(filaSeleccionada, 0).toString());
            // Aquí iría la llamada al DAO para eliminar
            modeloTabla.removeRow(filaSeleccionada);
            JOptionPane.showMessageDialog(this,
                "Vehículo eliminado correctamente",
                "Éxito",
                JOptionPane.INFORMATION_MESSAGE);

            // Después de eliminar el vehículo exitosamente
            mainFrame.getStatusPanel().actualizarAhora();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error al eliminar el vehículo: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarVehiculos() {
        String busqueda = txtFiltrar.getText().toLowerCase();
        // Implementar lógica de búsqueda
    }

    private void limpiarFormulario() {
        txtMarca.setText("");
        txtModelo.setText("");
        spnAño.setValue(2024);
        txtPrecio.setText("");
        setSelectedEstado("DISPONIBLE");
        txtColor.setText("");
        txtMatricula.setText("");
        spnKilometraje.setValue(0);
        chkGarantia.setSelected(false);
        txtMarca.requestFocus();
    }

    private JButton createButton(String text, String iconPath) {
        ImageIcon icon = null;
        try {
            URL imageUrl = getClass().getResource(iconPath);
            if (imageUrl != null) {
                icon = new ImageIcon(imageUrl);
            }
        } catch (Exception e) {
            System.err.println("No se pudo cargar el ícono: " + iconPath);
        }
        return new JButton(text, icon);
    }

    private void filtrar() {
        String texto = txtFiltrar.getText().toLowerCase();
        if (texto.trim().length() == 0) {
            sorter.setRowFilter(null);
        } else {
            // Filtrar por cualquier columna que contenga el texto
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto));
        }
    }

    private String getSelectedEstado() {
        for (Map.Entry<String, JRadioButton> entry : radioButtons.entrySet()) {
            if (entry.getValue().isSelected()) {
                return entry.getKey();
            }
        }
        return "DISPONIBLE"; // Valor por defecto
    }

    private void setSelectedEstado(String estado) {
        JRadioButton radio = radioButtons.get(estado);
        if (radio != null) {
            radio.setSelected(true);
        }
    }
} 