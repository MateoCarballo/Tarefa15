package com.concesionario.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.concesionario.model.Usuario;

public class LoginDialog extends JDialog {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnCancelar;
    private boolean loginExitoso;
    private Usuario usuarioAutenticado;

    public LoginDialog(Frame parent) {
        super(parent, "Iniciar Sesión", true);
        initComponents();
        setupLayout();
        setupListeners();
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        txtUsername = new JTextField(20);
        txtPassword = new JPasswordField(20);
        btnLogin = new JButton("Iniciar Sesión", new ImageIcon(getClass().getResource("/images/login.png")));
        btnCancelar = new JButton("Cancelar", new ImageIcon(getClass().getResource("/images/cancel.png")));
        loginExitoso = false;
        usuarioAutenticado = null;
    }

    private void setupLayout() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Icono de usuario
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel iconLabel = new JLabel(new ImageIcon(getClass().getResource("/images/user.png")));
        iconLabel.setHorizontalAlignment(JLabel.CENTER);
        panel.add(iconLabel, gbc);

        // Campo de usuario
        gbc.gridy = 1; gbc.gridwidth = 1;
        panel.add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1;
        panel.add(txtUsername, gbc);

        // Campo de contraseña
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1;
        panel.add(txtPassword, gbc);

        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(btnLogin);
        buttonPanel.add(btnCancelar);

        // Agregar todo al diálogo
        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Configurar accesibilidad
        configurarAccesibilidad();

        // Establecer tamaño mínimo
        setMinimumSize(new Dimension(300, 200));
    }

    private void setupListeners() {
        btnLogin.addActionListener(e -> autenticar());
        btnCancelar.addActionListener(e -> cancelar());

        // Permitir cerrar con Escape
        getRootPane().registerKeyboardAction(
            e -> cancelar(),
            KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
            JComponent.WHEN_IN_FOCUSED_WINDOW
        );

        // Permitir login con Enter
        getRootPane().setDefaultButton(btnLogin);
    }

    private void configurarAccesibilidad() {
        // Configurar tooltips
        txtUsername.setToolTipText("Ingrese su nombre de usuario");
        txtPassword.setToolTipText("Ingrese su contraseña");
        btnLogin.setToolTipText("Haga clic para iniciar sesión");
        btnCancelar.setToolTipText("Haga clic para cancelar");

        // Configurar mnemonics
        btnLogin.setMnemonic('I');
        btnCancelar.setMnemonic('C');

        // Configurar nombres accesibles
        txtUsername.getAccessibleContext().setAccessibleName("Campo de usuario");
        txtPassword.getAccessibleContext().setAccessibleName("Campo de contraseña");
    }

    private void autenticar() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Por favor, ingrese usuario y contraseña",
                "Error de validación",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // TODO: Implementar autenticación real contra la base de datos
        if ("admin".equals(username) && "admin".equals(password)) {
            loginExitoso = true;
            usuarioAutenticado = new Usuario();
            usuarioAutenticado.setUsername(username);
            usuarioAutenticado.setNombre("Administrador");
            usuarioAutenticado.setTipoUsuario(Usuario.TipoUsuario.ADMINISTRADOR);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                "Usuario o contraseña incorrectos",
                "Error de autenticación",
                JOptionPane.ERROR_MESSAGE);
            txtPassword.setText("");
            txtPassword.requestFocus();
        }
    }

    private void cancelar() {
        loginExitoso = false;
        usuarioAutenticado = null;
        dispose();
    }

    public boolean isLoginExitoso() {
        return loginExitoso;
    }

    public Usuario getUsuarioAutenticado() {
        return usuarioAutenticado;
    }
} 