package com.concesionario.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.border.EmptyBorder;
import java.sql.*;
import com.concesionario.util.DatabaseConnection;
import java.util.ArrayList;
import java.util.List;

public class StatusPanel extends JPanel {
    private JLabel vehiculosLabel;
    private JLabel clientesLabel;
    private JLabel ventasLabel;
    private JLabel ingresosTotalesLabel;
    private Timer actualizacionTimer;
    private final NumberFormat formatoMoneda;
    private List<StatusUpdateListener> listeners;

    public interface StatusUpdateListener {
        void onStatusUpdated();
    }

    public StatusPanel() {
        setLayout(new FlowLayout(FlowLayout.LEFT, 20, 5));
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, Color.GRAY),
            new EmptyBorder(5, 10, 5, 10)
        ));
        setBackground(new Color(245, 245, 245));

        formatoMoneda = NumberFormat.getCurrencyInstance(new Locale("es", "ES"));
        listeners = new ArrayList<>();

        inicializarComponentes();
        iniciarActualizacionAutomatica();
    }

    private void inicializarComponentes() {
        // Vehículos disponibles
        JPanel vehiculosPanel = crearPanelEstadistica("Vehículos disponibles", "0");
        vehiculosLabel = (JLabel) vehiculosPanel.getComponent(1);
        add(vehiculosPanel);

        // Separador vertical
        add(crearSeparadorVertical());

        // Total clientes
        JPanel clientesPanel = crearPanelEstadistica("Total clientes", "0");
        clientesLabel = (JLabel) clientesPanel.getComponent(1);
        add(clientesPanel);

        // Separador vertical
        add(crearSeparadorVertical());

        // Ventas del mes
        JPanel ventasPanel = crearPanelEstadistica("Ventas del mes", "0");
        ventasLabel = (JLabel) ventasPanel.getComponent(1);
        add(ventasPanel);

        // Separador vertical
        add(crearSeparadorVertical());

        // Ingresos totales
        JPanel ingresosPanel = crearPanelEstadistica("Ingresos totales", "0 €");
        ingresosTotalesLabel = (JLabel) ingresosPanel.getComponent(1);
        add(ingresosPanel);
    }

    private JPanel crearPanelEstadistica(String titulo, String valor) {
        JPanel panel = new JPanel(new GridLayout(2, 1, 0, 2));
        panel.setOpaque(false);

        JLabel tituloLabel = new JLabel(titulo);
        tituloLabel.setForeground(Color.GRAY);
        tituloLabel.setFont(new Font("Dialog", Font.PLAIN, 11));

        JLabel valorLabel = new JLabel(valor);
        valorLabel.setFont(new Font("Dialog", Font.BOLD, 14));

        panel.add(tituloLabel);
        panel.add(valorLabel);

        return panel;
    }

    private JSeparator crearSeparadorVertical() {
        JSeparator separador = new JSeparator(SwingConstants.VERTICAL);
        separador.setPreferredSize(new Dimension(1, 30));
        return separador;
    }

    private void iniciarActualizacionAutomatica() {
        // Actualizar cada 30 segundos
        actualizacionTimer = new Timer(30000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarEstadisticas();
            }
        });
        actualizacionTimer.start();
        
        // Primera actualización inmediata
        actualizarEstadisticas();
    }

    /**
     * Método público para forzar una actualización inmediata
     * Este método debe ser llamado después de cualquier operación que afecte a los datos mostrados
     */
    public void actualizarAhora() {
        actualizarEstadisticas();
        notifyListeners();
    }

    /**
     * Añade un listener para ser notificado cuando los datos se actualicen
     */
    public void addStatusUpdateListener(StatusUpdateListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    /**
     * Elimina un listener
     */
    public void removeStatusUpdateListener(StatusUpdateListener listener) {
        listeners.remove(listener);
    }

    private void notifyListeners() {
        for (StatusUpdateListener listener : listeners) {
            listener.onStatusUpdated();
        }
    }

    public void actualizarEstadisticas() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            // Contar vehículos disponibles
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM vehiculos WHERE estado = 'DISPONIBLE'")) {
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    vehiculosLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Contar total de clientes
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM clientes")) {
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    clientesLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Contar ventas del mes actual
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM ventas WHERE MONTH(fecha_venta) = MONTH(CURRENT_DATE) AND YEAR(fecha_venta) = YEAR(CURRENT_DATE)")) {
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    ventasLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Calcular ingresos totales
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT SUM(precio_venta) FROM ventas")) {
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    double ingresos = rs.getDouble(1);
                    ingresosTotalesLabel.setText(formatoMoneda.format(ingresos));
                }
            }

            // Notificar a los listeners después de la actualización
            notifyListeners();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error al actualizar las estadísticas: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    public void detener() {
        if (actualizacionTimer != null) {
            actualizacionTimer.stop();
        }
    }
} 