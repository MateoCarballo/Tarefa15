package com.concesionario.ui.components;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;

public class GraficoVentasPanel extends JPanel {
    private Map<String, BigDecimal> datosVentas;
    private Color[] colores;
    private boolean mostrarGraficoPastel;

    public GraficoVentasPanel() {
        this.datosVentas = new HashMap<>();
        this.mostrarGraficoPastel = true;
        initColores();
        setPreferredSize(new Dimension(400, 300));
        setBorder(BorderFactory.createTitledBorder("Estadísticas de Ventas"));
    }

    private void initColores() {
        colores = new Color[]{
            new Color(46, 204, 113),  // Verde esmeralda
            new Color(52, 152, 219),  // Azul claro
            new Color(155, 89, 182),  // Púrpura
            new Color(241, 196, 15),  // Amarillo
            new Color(230, 126, 34),  // Naranja
            new Color(231, 76, 60),   // Rojo
            new Color(26, 188, 156),  // Turquesa
            new Color(52, 73, 94)     // Azul oscuro
        };
    }

    public void setDatosVentas(Map<String, BigDecimal> datos) {
        this.datosVentas = new HashMap<>(datos);
        repaint();
    }

    public void setMostrarGraficoPastel(boolean mostrarPastel) {
        this.mostrarGraficoPastel = mostrarPastel;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (datosVentas.isEmpty()) {
            dibujarMensajeNoData(g2d);
            return;
        }

        if (mostrarGraficoPastel) {
            dibujarGraficoPastel(g2d);
        } else {
            dibujarGraficoBarras(g2d);
        }

        dibujarLeyenda(g2d);
        g2d.dispose();
    }

    private void dibujarMensajeNoData(Graphics2D g2d) {
        String mensaje = "No hay datos disponibles";
        FontMetrics fm = g2d.getFontMetrics();
        int x = (getWidth() - fm.stringWidth(mensaje)) / 2;
        int y = getHeight() / 2;
        g2d.drawString(mensaje, x, y);
    }

    private void dibujarGraficoPastel(Graphics2D g2d) {
        double total = datosVentas.values().stream()
            .mapToDouble(BigDecimal::doubleValue)
            .sum();

        int diameter = Math.min(getWidth(), getHeight()) - 100;
        int x = (getWidth() - diameter) / 2;
        int y = (getHeight() - diameter) / 2;

        double currentAngle = 0.0;
        int colorIndex = 0;

        for (Map.Entry<String, BigDecimal> entry : datosVentas.entrySet()) {
            double sliceAngle = (entry.getValue().doubleValue() / total) * 360.0;
            
            g2d.setColor(colores[colorIndex % colores.length]);
            g2d.fill(new Arc2D.Double(
                x, y, diameter, diameter,
                currentAngle, sliceAngle,
                Arc2D.PIE
            ));

            currentAngle += sliceAngle;
            colorIndex++;
        }
    }

    private void dibujarGraficoBarras(Graphics2D g2d) {
        int barWidth = 40;
        int spacing = 20;
        int startX = 50;
        int startY = getHeight() - 50;
        
        double maxValue = datosVentas.values().stream()
            .mapToDouble(BigDecimal::doubleValue)
            .max()
            .orElse(0.0);

        double scale = (getHeight() - 100) / maxValue;
        int colorIndex = 0;

        // Dibujar eje Y
        g2d.drawLine(startX, startY, startX, 20);
        
        // Dibujar eje X
        g2d.drawLine(startX, startY, getWidth() - 20, startY);

        int x = startX + spacing;
        for (Map.Entry<String, BigDecimal> entry : datosVentas.entrySet()) {
            int height = (int)(entry.getValue().doubleValue() * scale);
            
            g2d.setColor(colores[colorIndex % colores.length]);
            g2d.fill(new Rectangle2D.Double(x, startY - height, barWidth, height));
            g2d.setColor(Color.BLACK);
            g2d.draw(new Rectangle2D.Double(x, startY - height, barWidth, height));

            // Rotar texto para las etiquetas
            AffineTransform old = g2d.getTransform();
            g2d.rotate(-Math.PI/4, x + barWidth/2, startY + 5);
            g2d.drawString(entry.getKey(), x, startY + 20);
            g2d.setTransform(old);

            x += barWidth + spacing;
            colorIndex++;
        }
    }

    private void dibujarLeyenda(Graphics2D g2d) {
        int legendX = getWidth() - 150;
        int legendY = 30;
        int boxSize = 10;
        int spacing = 20;
        int colorIndex = 0;

        for (String vendedor : datosVentas.keySet()) {
            g2d.setColor(colores[colorIndex % colores.length]);
            g2d.fillRect(legendX, legendY, boxSize, boxSize);
            g2d.setColor(Color.BLACK);
            g2d.drawRect(legendX, legendY, boxSize, boxSize);
            g2d.drawString(vendedor, legendX + boxSize + 5, legendY + boxSize);
            
            legendY += spacing;
            colorIndex++;
        }
    }
} 