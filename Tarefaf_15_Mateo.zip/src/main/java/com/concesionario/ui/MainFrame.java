package com.concesionario.ui;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import com.formdev.flatlaf.FlatLightLaf;
import java.net.URL;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import com.concesionario.util.DatabaseConnection;
import com.concesionario.ui.components.StatusPanel;

public class MainFrame extends JFrame {
    private JPanel contentPane;
    private JTabbedPane tabbedPane;
    private JMenuBar menuBar;
    private StatusPanel statusPanel;

    public MainFrame() {
        setupLookAndFeel();
        initComponents();
        configureFrame();
    }

    private void setupLookAndFeel() {
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initComponents() {
        setTitle("Gestión de Concesionario - Desarrollado por Mateo Carballo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setMinimumSize(new Dimension(1000, 700));
        setLocationRelativeTo(null);

        // Crear el panel principal con BorderLayout
        contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);

        // Inicializar la barra de menú
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        // Inicializar el panel de estado
        statusPanel = new StatusPanel();
        
        // Inicializar el panel de pestañas
        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Clientes", new ClientesPanel(this));
        tabbedPane.addTab("Vehículos", new VehiculosPanel(this));
        tabbedPane.addTab("Ventas", new VentasPanel(this));
        tabbedPane.addTab("Informes", new InformesPanel());

        // Añadir los paneles al contentPane
        contentPane.add(tabbedPane, BorderLayout.CENTER);
        contentPane.add(statusPanel, BorderLayout.SOUTH);

        // Crear y configurar la barra de menú
        createMenus();
    }

    private void createMenus() {
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        // Menú Archivo
        JMenu menuArchivo = new JMenu("Archivo");
        menuArchivo.setMnemonic('A');
        
        JMenuItem menuItemSalir = new JMenuItem("Salir");
        menuItemSalir.setAccelerator(KeyStroke.getKeyStroke("alt F4"));
        menuItemSalir.addActionListener(e -> System.exit(0));
        menuArchivo.add(menuItemSalir);

        // Menú Ayuda
        JMenu menuAyuda = new JMenu("Ayuda");
        menuAyuda.setMnemonic('y');
        
        JMenuItem menuItemManual = new JMenuItem("Manual de Usuario");
        menuItemManual.setMnemonic('M');
        menuItemManual.setAccelerator(KeyStroke.getKeyStroke("F1"));
        menuItemManual.addActionListener(e -> mostrarManualUsuario());
        
        JMenuItem menuItemAcerca = new JMenuItem("Acerca de");
        menuItemAcerca.addActionListener(e -> mostrarAcercaDe());
        
        menuAyuda.add(menuItemManual);
        menuAyuda.addSeparator();
        menuAyuda.add(menuItemAcerca);

        menuBar.add(menuArchivo);
        menuBar.add(menuAyuda);
    }

    private void setupKeyboardShortcuts() {
        // Atajos para cambiar entre pestañas
        KeyStroke keyStrokeVehiculos = KeyStroke.getKeyStroke("alt V");
        KeyStroke keyStrokeClientes = KeyStroke.getKeyStroke("alt C");
        KeyStroke keyStrokeVentas = KeyStroke.getKeyStroke("alt N");
        KeyStroke keyStrokeInformes = KeyStroke.getKeyStroke("alt I");

        tabbedPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(keyStrokeVehiculos, "goToVehiculos");
        tabbedPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(keyStrokeClientes, "goToClientes");
        tabbedPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(keyStrokeVentas, "goToVentas");
        tabbedPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(keyStrokeInformes, "goToInformes");

        tabbedPane.getActionMap().put("goToVehiculos", new AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                tabbedPane.setSelectedIndex(0);
            }
        });
        
        tabbedPane.getActionMap().put("goToClientes", new AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                tabbedPane.setSelectedIndex(1);
            }
        });
        
        tabbedPane.getActionMap().put("goToVentas", new AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                tabbedPane.setSelectedIndex(2);
            }
        });
        
        tabbedPane.getActionMap().put("goToInformes", new AbstractAction() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                tabbedPane.setSelectedIndex(3);
            }
        });
    }

    private void configureFrame() {
        // Centrar la ventana
        setLocationRelativeTo(null);
        setupKeyboardShortcuts();
    }

    private void mostrarAcercaDe() {
        JOptionPane.showMessageDialog(this,
            "Gestión de Concesionario v1.0\n" +
            "Desarrollado por Mateo Carballo\n" +
            "© 2024 Todos los derechos reservados",
            "Acerca de",
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarManualUsuario() {
        String manual = """
            MANUAL DE USUARIO - GESTIÓN DE CONCESIONARIO
            ==========================================
            
            GUÍA DETALLADA DE USO
            --------------------
            
            1. GESTIÓN DE CLIENTES
            ---------------------
            Para acceder: Haz clic en la pestaña "Clientes" o pulsa Alt + C
            
            a) Añadir un nuevo cliente:
               1. Localiza y haz clic en el botón "Nuevo Cliente"
               2. Rellena los campos del formulario:
                  - Nombre: Introduce el nombre del cliente
                  - Apellidos: Introduce los apellidos
                  - DNI: Introduce el DNI (formato: 12345678A)
                  - Teléfono: Introduce el número de teléfono
                  - Email: Introduce el correo electrónico
                  - Dirección: Introduce la dirección completa
               3. Haz clic en "Guardar" para registrar el cliente
               
            b) Modificar un cliente existente:
               1. En la tabla de clientes, localiza el cliente a modificar
               2. Haz doble clic sobre la fila del cliente o selecciónalo y pulsa "Editar"
               3. Modifica los campos necesarios
               4. Haz clic en "Guardar" para aplicar los cambios
               
            c) Eliminar un cliente:
               1. Selecciona el cliente en la tabla
               2. Haz clic en el botón "Eliminar"
               3. Confirma la eliminación en el mensaje emergente
               
            d) Buscar clientes:
               1. Localiza el campo de búsqueda en la parte superior
               2. Escribe el nombre, apellidos o DNI del cliente
               3. La tabla se actualizará automáticamente mostrando las coincidencias
            
            2. GESTIÓN DE VEHÍCULOS
            ----------------------
            Para acceder: Haz clic en la pestaña "Vehículos" o pulsa Alt + V
            
            a) Registrar nuevo vehículo:
               1. Haz clic en "Nuevo Vehículo"
               2. Rellena el formulario:
                  - Marca: Selecciona o escribe la marca
                  - Modelo: Introduce el modelo
                  - Año: Selecciona el año de fabricación
                  - Precio: Introduce el precio base (solo números)
                  - Color: Introduce el color
                  - Matrícula: Introduce la matrícula (si tiene)
                  - Kilometraje: Introduce el kilometraje actual
                  - Estado: Selecciona entre (Disponible/Reservado/Vendido/En Revisión/Baja)
                  - Garantía: Marca la casilla si tiene garantía
               3. Haz clic en "Guardar"
               
            b) Modificar vehículo:
               1. Selecciona el vehículo en la tabla
               2. Haz clic en "Editar" o doble clic sobre el vehículo
               3. Modifica los campos necesarios
               4. Guarda los cambios
               
            c) Cambiar estado de un vehículo:
               1. Selecciona el vehículo
               2. Usa el menú desplegable de "Estado"
               3. Selecciona el nuevo estado
               4. Confirma el cambio
            
            3. GESTIÓN DE VENTAS
            -------------------
            Para acceder: Haz clic en la pestaña "Ventas" o pulsa Alt + N
            
            a) Registrar una nueva venta:
               1. En la parte superior del panel:
                  - Despliega el combo "Cliente" y selecciona el comprador
                  - Despliega el combo "Vehículo" y elige el vehículo a vender
               2. El precio original se mostrará automáticamente
               3. El precio de venta se calculará automáticamente (+15%)
               4. Configura la financiación:
                  - Selecciona "Sí" o "No" en el grupo "Financiación"
               5. Configura la entrada:
                  - Selecciona "Sí" o "No" en el grupo "Entrada"
                  - Si seleccionas "Sí", se habilitará el campo "Cantidad"
                  - Introduce la cantidad de entrada (solo si corresponde)
               6. Añade observaciones si es necesario
               7. Haz clic en "Guardar Venta"
               
            b) Consultar historial de ventas:
               1. En la parte inferior del panel encontrarás la tabla de ventas
               2. Las ventas están ordenadas por fecha (más recientes primero)
               3. Puedes ver todos los detalles:
                  - ID de la venta
                  - Fecha y hora
                  - Vehículo vendido
                  - Cliente comprador
                  - Precio final
                  - Si fue financiado
                  - Si tuvo entrada y cantidad
                  - Observaciones
               
            4. INFORMES
            ----------
            Para acceder: Haz clic en la pestaña "Informes" o pulsa Alt + I
            
            a) Generar un informe:
               1. Haz clic en "Generar Informe"
               2. El informe se mostrará en una nueva ventana
               3. Puedes:
                  - Navegar por las páginas
                  - Hacer zoom
                  - Imprimir el informe
                  
            b) Exportar a PDF:
               1. Haz clic en "Exportar a PDF"
               2. Selecciona la ubicación donde guardar
               3. El archivo se guardará como "report.pdf"
            
            5. PANEL DE ESTADO EN TIEMPO REAL
            ------------------------------
            Se ha implementado un panel de estado en la parte inferior de la aplicación que proporciona
            información crucial del concesionario en tiempo real.
            
            Ubicación y Diseño:
               • Se encuentra en la parte inferior de la ventana principal
               • Fondo gris claro para distinguirlo del resto de la interfaz
               • Separadores verticales para mejor organización visual
            
            Información Mostrada:
               1. Vehículos Disponibles:
                  - Muestra el número actual de vehículos marcados como "Disponible"
                  - Se actualiza automáticamente al cambiar el estado de los vehículos
                  - Ayuda a controlar el inventario disponible para venta
            
               2. Total de Clientes:
                  - Indica el número total de clientes registrados
                  - Útil para seguimiento de la base de clientes
                  - Se actualiza al añadir o eliminar clientes
            
               3. Ventas del Mes:
                  - Muestra el número de ventas realizadas en el mes actual
                  - Se reinicia automáticamente al comenzar un nuevo mes
                  - Permite seguimiento de objetivos mensuales
            
               4. Ingresos Totales:
                  - Suma total de todas las ventas realizadas
                  - Mostrado en formato de moneda (€)
                  - Incluye todas las ventas históricas
            
            Características Técnicas:
               • Actualización Automática:
                 - Los datos se actualizan cada 30 segundos
                 - No requiere intervención del usuario
                 - Garantiza información siempre actualizada
            
               • Integración con Base de Datos:
                 - Conexión directa con la base de datos
                 - Consultas optimizadas para rendimiento
                 - Manejo automático de errores
            
            Beneficios:
               • Visibilidad inmediata de métricas importantes
               • Ayuda en la toma de decisiones
               • Seguimiento en tiempo real del negocio
               • Reduce la necesidad de generar informes frecuentes
            
            Consideraciones:
               • Los datos mostrados son en tiempo real
               • No requiere actualización manual
               • En caso de error de conexión, se mostrará un mensaje
               • Los valores se reinician al cerrar y abrir la aplicación
            
            ATAJOS DE TECLADO
            ----------------
            • F1: Mostrar este manual de ayuda
            • Alt + F4: Cerrar la aplicación
            • Alt + V: Ir a Vehículos
            • Alt + C: Ir a Clientes
            • Alt + N: Ir a Ventas
            • Alt + I: Ir a Informes
            
            CONSEJOS ÚTILES
            --------------
            • Puedes redimensionar las columnas de las tablas arrastrando sus bordes
            • En las ventas, el precio de venta se calcula automáticamente pero puedes modificarlo
            • Los campos obligatorios están marcados con un asterisco (*)
            • Usa la tecla Tab para moverte entre campos
            • Puedes ordenar las tablas haciendo clic en las cabeceras de las columnas
            
            Para cualquier duda adicional o soporte técnico, contacta con:
            Mateo Carballo
            Desarrollador del Sistema
            """;

        // Crear un JTextArea para mostrar el manual
        JTextArea textArea = new JTextArea(manual);
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        textArea.setMargin(new Insets(10, 10, 10, 10));
        
        // Crear un JScrollPane para permitir desplazamiento
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(800, 600));

        // Mostrar el diálogo
        JOptionPane.showMessageDialog(this,
            scrollPane,
            "Manual de Usuario",
            JOptionPane.PLAIN_MESSAGE);
    }

    private void mostrarInforme(ActionEvent evt) {
        try {
            // Ruta al archivo .jrxml de tu informe
            String reportPath = "src/main/java/reports/report.jrxml";

            // Cargar y compilar el informe
            JasperReport jasperReport = JasperCompileManager.compileReport(reportPath);

            // Obtener la conexión usando DatabaseConnection
            java.sql.Connection conn = DatabaseConnection.getConnection();

            // Parámetros del informe (vacío si no necesitas parámetros)
            Map<String, Object> parameters = new HashMap<>();

            // Llenar el informe con los datos
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, conn);

            // Mostrar el informe
            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setVisible(true);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error al generar el informe: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    @Override
    public void dispose() {
        if (statusPanel != null) {
            statusPanel.detener();
        }
        super.dispose();
    }

    /**
     * Obtiene el panel de estado para que otros componentes puedan actualizarlo
     */
    public StatusPanel getStatusPanel() {
        return statusPanel;
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
} 