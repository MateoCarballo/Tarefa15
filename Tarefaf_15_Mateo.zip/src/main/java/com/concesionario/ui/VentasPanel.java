package com.concesionario.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.concesionario.model.Venta;
import com.concesionario.model.Vehiculo;
import com.concesionario.model.Cliente;
import com.concesionario.model.Usuario;
import java.util.Vector;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import com.concesionario.util.DatabaseConnection;
import java.time.LocalDate;
import java.math.RoundingMode;

public class VentasPanel extends JPanel {
    private JTable tablaVentas;
    private DefaultTableModel modeloTabla;
    private JComboBox<VehiculoItem> comboVehiculos;
    private JComboBox<ClienteItem> comboClientes;
    private JTextField txtPrecioVenta;
    private JTextField txtCantidadEntrada;
    private JTextArea txtObservaciones;
    private JButton btnGuardar;
    private JRadioButton rbFinanciacionSi;
    private JRadioButton rbFinanciacionNo;
    private JRadioButton rbEntradaSi;
    private JRadioButton rbEntradaNo;
    private JLabel lblPrecioOriginal;
    private JLabel lblCantidadEntrada;
    private Usuario usuarioActual;
    private MainFrame mainFrame;

    public VentasPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout(10, 10));
        initComponents();
        setupLayout();
        loadData();
        cargarVentasExistentes();
    }

    private void initComponents() {
        // Panel principal con GridBagLayout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Selector de Cliente
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(new JLabel("Cliente:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        comboClientes = new JComboBox<>();
        mainPanel.add(comboClientes, gbc);

        // Selector de Vehículo
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        mainPanel.add(new JLabel("Vehículo:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        comboVehiculos = new JComboBox<>();
        comboVehiculos.addActionListener(e -> actualizarPrecioVenta());
        mainPanel.add(comboVehiculos, gbc);

        // Precio Original (solo mostrar)
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        mainPanel.add(new JLabel("Precio Original:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        lblPrecioOriginal = new JLabel("0 €");
        mainPanel.add(lblPrecioOriginal, gbc);

        // Precio de Venta
        gbc.gridx = 0;
        gbc.gridy = 3;
        mainPanel.add(new JLabel("Precio de Venta:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        txtPrecioVenta = new JTextField();
        mainPanel.add(txtPrecioVenta, gbc);

        // Panel de Financiación
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 3;
        JPanel financiacionPanel = new JPanel();
        financiacionPanel.setBorder(BorderFactory.createTitledBorder("Financiación"));
        ButtonGroup groupFinanciacion = new ButtonGroup();
        rbFinanciacionSi = new JRadioButton("Sí");
        rbFinanciacionNo = new JRadioButton("No");
        rbFinanciacionNo.setSelected(true);
        groupFinanciacion.add(rbFinanciacionSi);
        groupFinanciacion.add(rbFinanciacionNo);
        financiacionPanel.add(rbFinanciacionSi);
        financiacionPanel.add(rbFinanciacionNo);
        mainPanel.add(financiacionPanel, gbc);

        // Panel de Entrada
        gbc.gridx = 0;
        gbc.gridy = 5;
        JPanel entradaPanel = new JPanel(new GridBagLayout());
        entradaPanel.setBorder(BorderFactory.createTitledBorder("Entrada"));
        
        GridBagConstraints gbcEntrada = new GridBagConstraints();
        gbcEntrada.insets = new Insets(5, 5, 5, 5);
        gbcEntrada.anchor = GridBagConstraints.WEST;
        
        ButtonGroup groupEntrada = new ButtonGroup();
        rbEntradaSi = new JRadioButton("Sí");
        rbEntradaNo = new JRadioButton("No");
        rbEntradaNo.setSelected(true);
        groupEntrada.add(rbEntradaSi);
        groupEntrada.add(rbEntradaNo);
        
        entradaPanel.add(rbEntradaSi, gbcEntrada);
        entradaPanel.add(rbEntradaNo, gbcEntrada);
        
        // Campo para la cantidad de entrada
        lblCantidadEntrada = new JLabel("Cantidad:");
        txtCantidadEntrada = new JTextField(10);
        txtCantidadEntrada.setEnabled(false);
        
        gbcEntrada.gridx = 2;
        entradaPanel.add(lblCantidadEntrada, gbcEntrada);
        gbcEntrada.gridx = 3;
        entradaPanel.add(txtCantidadEntrada, gbcEntrada);
        
        mainPanel.add(entradaPanel, gbc);

        // Añadir listener para habilitar/deshabilitar el campo de cantidad de entrada
        rbEntradaSi.addActionListener(e -> txtCantidadEntrada.setEnabled(true));
        rbEntradaNo.addActionListener(e -> {
            txtCantidadEntrada.setEnabled(false);
            txtCantidadEntrada.setText("");
        });

        // Observaciones
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 1;
        mainPanel.add(new JLabel("Observaciones:"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        txtObservaciones = new JTextArea(3, 20);
        txtObservaciones.setLineWrap(true);
        txtObservaciones.setWrapStyleWord(true);
        JScrollPane scrollObservaciones = new JScrollPane(txtObservaciones);
        mainPanel.add(scrollObservaciones, gbc);

        // Botón Guardar
        gbc.gridx = 1;
        gbc.gridy = 7;
        gbc.gridwidth = 1;
        btnGuardar = new JButton("Guardar Venta");
        btnGuardar.setBackground(new Color(70, 130, 180));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);
        btnGuardar.addActionListener(e -> guardarVenta());
        mainPanel.add(btnGuardar, gbc);

        // Tabla de ventas
        String[] columnas = {"ID", "Fecha", "Vehículo", "Cliente", "Precio", "Financiado", "Entrada", "Cantidad Entrada", "Observaciones"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaVentas = new JTable(modeloTabla);
        tablaVentas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaVentas.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        
        JScrollPane scrollPane = new JScrollPane(tablaVentas);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        // Panel principal con división entre formulario y tabla
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setTopComponent(mainPanel);
        splitPane.setBottomComponent(scrollPane);
        splitPane.setResizeWeight(0.4);
        
        add(splitPane, BorderLayout.CENTER);
    }

    private void setupLayout() {
        // Configurar tooltips y accesibilidad
        comboVehiculos.setToolTipText("Seleccione el vehículo a vender");
        comboClientes.setToolTipText("Seleccione el cliente comprador");
        txtPrecioVenta.setToolTipText("Precio final de venta");
        txtObservaciones.setToolTipText("Observaciones sobre la venta");
    }

    private void loadData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            
            // Cargar clientes con todos sus campos
            String queryClientes = "SELECT id, nombre, apellidos, dni, telefono, email, direccion FROM clientes";
            PreparedStatement stmtClientes = conn.prepareStatement(queryClientes);
            ResultSet rsClientes = stmtClientes.executeQuery();
            
            comboClientes.removeAllItems();
            while (rsClientes.next()) {
                ClienteItem cliente = new ClienteItem(
                    rsClientes.getLong("id"),
                    rsClientes.getString("nombre"),
                    rsClientes.getString("apellidos"),
                    rsClientes.getString("dni"),
                    rsClientes.getString("telefono"),
                    rsClientes.getString("email"),
                    rsClientes.getString("direccion")
                );
                comboClientes.addItem(cliente);
            }

            // Cargar vehículos disponibles con todos sus campos
            String queryVehiculos = "SELECT id, marca, modelo, año, precio, color, matricula, kilometraje, garantia " +
                                  "FROM vehiculos WHERE estado = 'DISPONIBLE'";
            PreparedStatement stmtVehiculos = conn.prepareStatement(queryVehiculos);
            ResultSet rsVehiculos = stmtVehiculos.executeQuery();
            
            comboVehiculos.removeAllItems();
            while (rsVehiculos.next()) {
                VehiculoItem vehiculo = new VehiculoItem(
                    rsVehiculos.getLong("id"),
                    rsVehiculos.getString("marca"),
                    rsVehiculos.getString("modelo"),
                    rsVehiculos.getInt("año"),
                    rsVehiculos.getDouble("precio"),
                    rsVehiculos.getString("color"),
                    rsVehiculos.getString("matricula"),
                    rsVehiculos.getInt("kilometraje"),
                    rsVehiculos.getBoolean("garantia")
                );
                comboVehiculos.addItem(vehiculo);
            }

            // Si no hay elementos, mostrar mensaje
            if (comboVehiculos.getItemCount() == 0) {
                JOptionPane.showMessageDialog(this,
                    "No hay vehículos disponibles para la venta",
                    "Información",
                    JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "Error al cargar los datos: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void actualizarPrecioVenta() {
        VehiculoItem vehiculo = (VehiculoItem) comboVehiculos.getSelectedItem();
        if (vehiculo != null) {
            double precioOriginal = vehiculo.getPrecio();
            lblPrecioOriginal.setText(String.format("%.2f €", precioOriginal));
            
            // Calcular precio de venta (15% más que el precio original)
            double precioVenta = precioOriginal * 1.15;
            txtPrecioVenta.setText(String.format("%.2f", precioVenta));
        }
    }

    private void cargarVentasExistentes() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String query = "SELECT v.id, v.fecha_venta, vh.marca, vh.modelo, " +
                         "c.nombre, c.apellidos, v.precio_venta, v.financiado, " +
                         "v.entrada, v.cantidad_entrada, v.observaciones " +
                         "FROM ventas v " +
                         "JOIN vehiculos vh ON v.vehiculo_id = vh.id " +
                         "JOIN clientes c ON v.cliente_id = c.id " +
                         "ORDER BY v.fecha_venta DESC";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            modeloTabla.setRowCount(0); // Limpiar tabla
            
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getLong("id"));
                row.add(rs.getTimestamp("fecha_venta").toLocalDateTime().format(
                    DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
                row.add(rs.getString("marca") + " " + rs.getString("modelo"));
                row.add(rs.getString("nombre") + " " + rs.getString("apellidos"));
                row.add(String.format("%.2f €", rs.getDouble("precio_venta")));
                row.add(rs.getBoolean("financiado") ? "Sí" : "No");
                row.add(rs.getBoolean("entrada") ? "Sí" : "No");
                row.add(rs.getDouble("cantidad_entrada") > 0 ? 
                    String.format("%.2f €", rs.getDouble("cantidad_entrada")) : "-");
                row.add(rs.getString("observaciones"));
                modeloTabla.addRow(row);
            }

            // Ajustar el ancho de las columnas
            ajustarColumnasTabla();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "Error al cargar las ventas: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void ajustarColumnasTabla() {
        // ID - pequeño
        tablaVentas.getColumnModel().getColumn(0).setPreferredWidth(50);
        
        // Fecha - medio
        tablaVentas.getColumnModel().getColumn(1).setPreferredWidth(120);
        
        // Vehículo - grande
        tablaVentas.getColumnModel().getColumn(2).setPreferredWidth(200);
        
        // Cliente - grande
        tablaVentas.getColumnModel().getColumn(3).setPreferredWidth(200);
        
        // Precio - medio
        tablaVentas.getColumnModel().getColumn(4).setPreferredWidth(100);
        
        // Financiado - pequeño
        tablaVentas.getColumnModel().getColumn(5).setPreferredWidth(70);
        
        // Entrada - pequeño
        tablaVentas.getColumnModel().getColumn(6).setPreferredWidth(70);
        
        // Cantidad Entrada - medio
        tablaVentas.getColumnModel().getColumn(7).setPreferredWidth(100);
        
        // Observaciones - muy grande
        tablaVentas.getColumnModel().getColumn(8).setPreferredWidth(300);
    }

    private void guardarVenta() {
        try {
            ClienteItem cliente = (ClienteItem) comboClientes.getSelectedItem();
            VehiculoItem vehiculo = (VehiculoItem) comboVehiculos.getSelectedItem();
            
            if (cliente == null || vehiculo == null) {
                JOptionPane.showMessageDialog(this,
                    "Por favor, seleccione un cliente y un vehículo",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validar cantidad de entrada si está seleccionada
            double cantidadEntrada = 0;
            if (rbEntradaSi.isSelected()) {
                if (txtCantidadEntrada.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this,
                        "Por favor, ingrese la cantidad de entrada",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    cantidadEntrada = Double.parseDouble(txtCantidadEntrada.getText().replace(",", "."));
                    if (cantidadEntrada <= 0) {
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this,
                        "La cantidad de entrada debe ser un número válido mayor que cero",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            Connection conn = DatabaseConnection.getConnection();
            
            // Insertar la venta
            String insertVenta = "INSERT INTO ventas (vehiculo_id, cliente_id, fecha_venta, precio_venta, financiado, entrada, cantidad_entrada, observaciones) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(insertVenta);
            
            stmt.setLong(1, vehiculo.getId());
            stmt.setLong(2, cliente.getId());
            stmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setDouble(4, Double.parseDouble(txtPrecioVenta.getText().replace(",", ".")));
            stmt.setBoolean(5, rbFinanciacionSi.isSelected());
            stmt.setBoolean(6, rbEntradaSi.isSelected());
            stmt.setDouble(7, cantidadEntrada);
            stmt.setString(8, txtObservaciones.getText());
            
            stmt.executeUpdate();

            // Actualizar el estado del vehículo a 'vendido'
            String updateVehiculo = "UPDATE vehiculos SET estado = 'VENDIDO' WHERE id = ?";
            PreparedStatement stmtUpdate = conn.prepareStatement(updateVehiculo);
            stmtUpdate.setLong(1, vehiculo.getId());
            stmtUpdate.executeUpdate();

            JOptionPane.showMessageDialog(this,
                "Venta registrada correctamente",
                "Éxito",
                JOptionPane.INFORMATION_MESSAGE);

            // Recargar los datos
            loadData();
            cargarVentasExistentes();
            limpiarFormulario();

            // Después de guardar la venta exitosamente
            mainFrame.getStatusPanel().actualizarAhora();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error al guardar la venta: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void limpiarFormulario() {
        comboClientes.setSelectedIndex(-1);
        comboVehiculos.setSelectedIndex(-1);
        txtPrecioVenta.setText("");
        lblPrecioOriginal.setText("0 €");
        rbFinanciacionNo.setSelected(true);
        rbEntradaNo.setSelected(true);
        txtCantidadEntrada.setText("");
        txtCantidadEntrada.setEnabled(false);
        txtObservaciones.setText("");
    }

    public void setUsuarioActual(Usuario usuario) {
        this.usuarioActual = usuario;
    }

    // Clases auxiliares para los ComboBox con todos los campos
    private class ClienteItem {
        private final long id;
        private final String nombre;
        private final String apellidos;
        private final String dni;
        private final String telefono;
        private final String email;
        private final String direccion;

        public ClienteItem(long id, String nombre, String apellidos, String dni, 
                         String telefono, String email, String direccion) {
            this.id = id;
            this.nombre = nombre;
            this.apellidos = apellidos;
            this.dni = dni;
            this.telefono = telefono;
            this.email = email;
            this.direccion = direccion;
        }

        public long getId() { return id; }

        @Override
        public String toString() {
            return String.format("%s %s - DNI: %s - Tel: %s", 
                nombre, apellidos, dni, 
                telefono != null ? telefono : "No disponible");
        }

        // Getters para todos los campos
        public String getNombre() { return nombre; }
        public String getApellidos() { return apellidos; }
        public String getDni() { return dni; }
        public String getTelefono() { return telefono; }
        public String getEmail() { return email; }
        public String getDireccion() { return direccion; }
    }

    private class VehiculoItem {
        private final long id;
        private final String marca;
        private final String modelo;
        private final int año;
        private final double precio;
        private final String color;
        private final String matricula;
        private final int kilometraje;
        private final boolean garantia;

        public VehiculoItem(long id, String marca, String modelo, int año, 
                          double precio, String color, String matricula, 
                          int kilometraje, boolean garantia) {
            this.id = id;
            this.marca = marca;
            this.modelo = modelo;
            this.año = año;
            this.precio = precio;
            this.color = color;
            this.matricula = matricula;
            this.kilometraje = kilometraje;
            this.garantia = garantia;
        }

        public long getId() { return id; }
        public double getPrecio() { return precio; }

        @Override
        public String toString() {
            return String.format("%s %s (%d) - %s - %.2f € - %d km%s", 
                marca, modelo, año, color, precio, kilometraje,
                garantia ? " - Con garantía" : "");
        }

        // Getters para todos los campos
        public String getMarca() { return marca; }
        public String getModelo() { return modelo; }
        public int getAño() { return año; }
        public String getColor() { return color; }
        public String getMatricula() { return matricula; }
        public int getKilometraje() { return kilometraje; }
        public boolean tieneGarantia() { return garantia; }
    }
} 