package com.concesionario.ui;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;
import com.concesionario.util.DatabaseConnection;

public class InformesPanel extends JPanel {
    private JButton btnGenerarInforme;
    private JButton btnExportarPDF;
    private JPanel panelBotones;
    private JPanel panelContenido;
    private static final String[] REPORT_PATHS = {
        "/reports/report.jrxml",
        "reports/report.jrxml",
        "src/main/resources/reports/report.jrxml",
        "src/main/java/reports/report.jrxml"
    };

    public InformesPanel() {
        setLayout(new BorderLayout(10, 10));
        initComponents();
        setupLayout();
    }

    private void initComponents() {
        // Inicializar componentes
        btnGenerarInforme = new JButton("Generar Informe");
        btnExportarPDF = new JButton("Exportar a PDF");
        
        // Configurar el aspecto de los botones
        btnGenerarInforme.setFont(new Font("Arial", Font.BOLD, 14));
        btnGenerarInforme.setBackground(new Color(70, 130, 180));
        btnGenerarInforme.setForeground(Color.WHITE);
        btnGenerarInforme.setFocusPainted(false);
        btnGenerarInforme.addActionListener(e -> generarInforme());
        
        btnExportarPDF.setFont(new Font("Arial", Font.BOLD, 14));
        btnExportarPDF.setBackground(new Color(60, 179, 113));
        btnExportarPDF.setForeground(Color.WHITE);
        btnExportarPDF.setFocusPainted(false);
        btnExportarPDF.addActionListener(e -> exportarAPDF());
        
        // Panel de botones
        panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Panel de contenido principal
        panelContenido = new JPanel(new BorderLayout());
        panelContenido.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Añadir una etiqueta descriptiva
        JLabel lblDescripcion = new JLabel("<html><div style='text-align: center;'>" +
            "<h2>Generación de Informes</h2>" +
            "<p>Esta sección permite generar informes detallados del concesionario.</p>" +
            "<p>El informe general incluye información sobre:</p>" +
            "<ul>" +
            "<li>Usuarios del sistema</li>" +
            "<li>Clientes registrados</li>" +
            "<li>Inventario de vehículos</li>" +
            "<li>Registro de ventas</li>" +
            "</ul>" +
            "</div></html>");
        lblDescripcion.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Añadir componentes a los paneles
        panelBotones.add(btnGenerarInforme);
        panelBotones.add(btnExportarPDF);
        panelContenido.add(lblDescripcion, BorderLayout.CENTER);
    }

    private void setupLayout() {
        // Configurar el layout del panel principal
        add(panelContenido, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private JasperReport compileReport() throws JRException {
        StringBuilder errorMessages = new StringBuilder();
        
        // Primero intentar cargar desde el classpath
        for (String path : REPORT_PATHS) {
            try {
                InputStream reportStream = getClass().getResourceAsStream(path);
                if (reportStream != null) {
                    return JasperCompileManager.compileReport(reportStream);
                }
            } catch (Exception e) {
                errorMessages.append("Fallo al intentar cargar desde ").append(path)
                           .append(": ").append(e.getMessage()).append("\n");
            }
        }
        
        // Si no se encontró en el classpath, intentar como archivo
        for (String path : REPORT_PATHS) {
            try {
                File reportFile = new File(path);
                if (reportFile.exists()) {
                    return JasperCompileManager.compileReport(reportFile.getAbsolutePath());
                }
            } catch (Exception e) {
                errorMessages.append("Fallo al intentar cargar el archivo ").append(path)
                           .append(": ").append(e.getMessage()).append("\n");
            }
        }
        
        throw new JRException("No se pudo encontrar el archivo de informe en ninguna ubicación:\n" + errorMessages.toString());
    }

    private void generarInforme() {
        try {
            setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            
            // Compilar el informe
            JasperReport jasperReport = compileReport();
            
            // Obtener la conexión
            Connection conn = DatabaseConnection.getConnection();
            
            // Parámetros del informe (vacío si no necesitas parámetros)
            Map<String, Object> parameters = new HashMap<>();
            
            // Llenar el informe con los datos
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, conn);
            
            // Mostrar el informe
            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setTitle("Informe General del Concesionario");
            viewer.setVisible(true);
            
        } catch (Exception ex) {
            String mensaje = "Error al generar el informe:\n" + ex.getMessage();
            if (ex.getCause() != null) {
                mensaje += "\nCausa: " + ex.getCause().getMessage();
            }
            JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            setCursor(Cursor.getDefaultCursor());
        }
    }

    private void exportarAPDF() {
        try {
            setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            
            // Compilar el informe
            JasperReport jasperReport = compileReport();
            
            // Obtener la conexión
            Connection conn = DatabaseConnection.getConnection();
            
            // Parámetros del informe
            Map<String, Object> parameters = new HashMap<>();
            
            // Llenar el informe con los datos
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, conn);
            
            // Obtener la ruta del escritorio
            String desktopPath = System.getProperty("user.home") + File.separator + "Desktop";
            
            // Verificar si existe la carpeta "Desktop" o "Escritorio"
            File desktop = new File(desktopPath);
            if (!desktop.exists()) {
                // Intentar con "Escritorio" para sistemas en español
                desktopPath = System.getProperty("user.home") + File.separator + "Escritorio";
                desktop = new File(desktopPath);
                if (!desktop.exists()) {
                    throw new Exception("No se pudo encontrar la carpeta del escritorio");
                }
            }
            
            // Crear nombre del archivo con fecha y hora
            String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
            String outputFile = desktopPath + File.separator + "Informe_Concesionario_" + timestamp + ".pdf";
            
            // Exportar a PDF
            JasperExportManager.exportReportToPdfFile(jasperPrint, outputFile);
            
            // Mostrar mensaje de éxito con la ruta del archivo
            JOptionPane.showMessageDialog(this,
                "Informe exportado exitosamente a:\n" + outputFile,
                "Éxito",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Abrir el directorio del escritorio
            Desktop.getDesktop().open(desktop);
            
        } catch (Exception ex) {
            String mensaje = "Error al exportar el informe:\n" + ex.getMessage();
            if (ex.getCause() != null) {
                mensaje += "\nCausa: " + ex.getCause().getMessage();
            }
            JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            setCursor(Cursor.getDefaultCursor());
        }
    }
} 