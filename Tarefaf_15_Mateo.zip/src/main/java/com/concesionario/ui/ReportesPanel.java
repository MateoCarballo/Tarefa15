package com.concesionario.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.util.Map;
import java.util.HashMap;
import com.concesionario.ui.components.GraficoVentasPanel;

public class ReportesPanel extends JPanel {
    private GraficoVentasPanel graficoVentas;
    private JComboBox<String> cmbTipoGrafico;
    private JComboBox<String> cmbTipoReporte;
    private JButton btnGenerar;
    private JButton btnExportar;
    private JPanel panelFiltros;
    private JComboBox<String> cmbPeriodo;
    private JSpinner spnAño;
    private JSpinner spnMes;

    public ReportesPanel() {
        setLayout(new BorderLayout(5, 5));
        initComponents();
        setupLayout();
        setupListeners();
    }

    private void initComponents() {
        // Componentes de control
        cmbTipoGrafico = new JComboBox<>(new String[]{"Gráfico de Pastel", "Gráfico de Barras"});
        cmbTipoReporte = new JComboBox<>(new String[]{
            "Ventas por Vendedor",
            "Ventas por Marca",
            "Ventas por Mes",
            "Stock Actual por Marca"
        });
        cmbPeriodo = new JComboBox<>(new String[]{
            "Último Mes",
            "Último Trimestre",
            "Último Año",
            "Personalizado"
        });

        // Spinners para fecha
        spnAño = new JSpinner(new SpinnerNumberModel(2024, 2000, 2024, 1));
        spnMes = new JSpinner(new SpinnerNumberModel(1, 1, 12, 1));

        // Botones (sin íconos temporalmente)
        btnGenerar = new JButton("Generar Reporte");
        btnExportar = new JButton("Exportar a PDF");

        // Panel de gráfico personalizado
        graficoVentas = new GraficoVentasPanel();

        // Panel de filtros
        panelFiltros = new JPanel();
    }

    private void setupLayout() {
        // Panel superior con controles
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        controlPanel.add(new JLabel("Tipo de Reporte:"));
        controlPanel.add(cmbTipoReporte);
        controlPanel.add(new JLabel("Visualización:"));
        controlPanel.add(cmbTipoGrafico);
        controlPanel.add(btnGenerar);
        controlPanel.add(btnExportar);

        // Panel de filtros
        panelFiltros.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 5));
        panelFiltros.setBorder(BorderFactory.createTitledBorder("Filtros"));
        panelFiltros.add(new JLabel("Periodo:"));
        panelFiltros.add(cmbPeriodo);
        panelFiltros.add(new JLabel("Año:"));
        panelFiltros.add(spnAño);
        panelFiltros.add(new JLabel("Mes:"));
        panelFiltros.add(spnMes);

        // Panel superior combinado
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(controlPanel, BorderLayout.NORTH);
        topPanel.add(panelFiltros, BorderLayout.CENTER);

        // Agregar componentes al panel principal
        add(topPanel, BorderLayout.NORTH);
        add(graficoVentas, BorderLayout.CENTER);

        // Configurar estado inicial
        actualizarEstadoFiltros();
    }

    private void setupListeners() {
        btnGenerar.addActionListener(this::generarReporte);
        btnExportar.addActionListener(this::exportarReporte);
        cmbTipoGrafico.addActionListener(e -> actualizarTipoGrafico());
        cmbPeriodo.addActionListener(e -> actualizarEstadoFiltros());
        
        // Configurar accesibilidad
        configurarAccesibilidad();
    }

    private void configurarAccesibilidad() {
        // Configurar tooltips
        cmbTipoReporte.setToolTipText("Seleccione el tipo de reporte a generar");
        cmbTipoGrafico.setToolTipText("Seleccione el tipo de visualización");
        cmbPeriodo.setToolTipText("Seleccione el periodo de tiempo para el reporte");
        spnAño.setToolTipText("Seleccione el año");
        spnMes.setToolTipText("Seleccione el mes");
        btnGenerar.setToolTipText("Generar el reporte con los filtros seleccionados");
        btnExportar.setToolTipText("Exportar el reporte actual a PDF");

        // Configurar mnemonics
        btnGenerar.setMnemonic('G');
        btnExportar.setMnemonic('E');

        // Configurar nombres accesibles
        cmbTipoReporte.getAccessibleContext().setAccessibleName("Selector de tipo de reporte");
        cmbTipoGrafico.getAccessibleContext().setAccessibleName("Selector de tipo de gráfico");
        cmbPeriodo.getAccessibleContext().setAccessibleName("Selector de periodo");
        spnAño.getAccessibleContext().setAccessibleName("Selector de año");
        spnMes.getAccessibleContext().setAccessibleName("Selector de mes");
    }

    private void actualizarEstadoFiltros() {
        boolean personalizado = "Personalizado".equals(cmbPeriodo.getSelectedItem());
        spnAño.setEnabled(personalizado);
        spnMes.setEnabled(personalizado);
    }

    private void actualizarTipoGrafico() {
        graficoVentas.setMostrarGraficoPastel(
            "Gráfico de Pastel".equals(cmbTipoGrafico.getSelectedItem())
        );
    }

    private void generarReporte(ActionEvent e) {
        try {
            // Simulación de datos para el ejemplo
            Map<String, BigDecimal> datos = new HashMap<>();
            datos.put("Vendedor 1", new BigDecimal("150000"));
            datos.put("Vendedor 2", new BigDecimal("280000"));
            datos.put("Vendedor 3", new BigDecimal("95000"));
            datos.put("Vendedor 4", new BigDecimal("320000"));

            graficoVentas.setDatosVentas(datos);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error al generar el reporte: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportarReporte(ActionEvent e) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar Reporte PDF");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
            "Archivos PDF (*.pdf)", "pdf"));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                // Implementar la generación del PDF con JasperReports
                JOptionPane.showMessageDialog(this,
                    "Reporte exportado exitosamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                    "Error al exportar el reporte: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
} 