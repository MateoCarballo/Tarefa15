package com.concesionario.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class VehiculoDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/concesionario";
    private static final String USER = "root";
    private static final String PASSWORD = "abc123.";

    public List<Object[]> obtenerTodosLosVehiculos() {
        List<Object[]> vehiculos = new ArrayList<>();
        String query = "SELECT id, marca, modelo, año, precio, estado, color, matricula, kilometraje FROM vehiculos";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Object[] vehiculo = {
                    rs.getInt("id"),
                    rs.getString("marca"),
                    rs.getString("modelo"),
                    rs.getInt("año"),
                    String.format("%.2f €", rs.getDouble("precio")),
                    rs.getString("estado"),
                    rs.getString("color"),
                    rs.getString("matricula"),
                    rs.getInt("kilometraje")
                };
                vehiculos.add(vehiculo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                "Error al cargar los vehículos: " + e.getMessage(),
                "Error de Base de Datos",
                JOptionPane.ERROR_MESSAGE);
        }

        return vehiculos;
    }

    public boolean actualizarVehiculo(int id, String marca, String modelo, int año, 
                                    double precio, String estado, String color, 
                                    String matricula, int kilometraje) {
        String query = "UPDATE vehiculos SET marca=?, modelo=?, año=?, precio=?, " +
                      "estado=?, color=?, matricula=?, kilometraje=? WHERE id=?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, marca);
            pstmt.setString(2, modelo);
            pstmt.setInt(3, año);
            pstmt.setDouble(4, precio);
            pstmt.setString(5, estado);
            pstmt.setString(6, color);
            pstmt.setString(7, matricula);
            pstmt.setInt(8, kilometraje);
            pstmt.setInt(9, id);

            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                "Error al actualizar el vehículo: " + e.getMessage(),
                "Error de Base de Datos",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
} 