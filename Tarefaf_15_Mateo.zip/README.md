# Gestión de Concesionario

Aplicación de escritorio para la gestión integral de un concesionario de vehículos, desarrollada en Java con interfaz gráfica Swing y persistencia de datos con Hibernate.

## 🚗 Características

- Gestión completa de vehículos (alta, baja, modificación)
- Registro y seguimiento de ventas
- Gestión de clientes y vendedores
- Sistema de usuarios con autenticación
- Generación de reportes en PDF
- Interfaz gráfica moderna y accesible
- Visualización de estadísticas con gráficos personalizados

## 🛠️ Tecnologías utilizadas

- Java 17
- Maven
- Hibernate ORM
- MySQL
- Swing (GUI)
- FlatLaf (Look and Feel moderno)
- JasperReports (Generación de reportes)
- Lombok (Reducción de código boilerplate)

## 📋 Requisitos previos

- JDK 17 o superior
- Maven 3.6 o superior
- MySQL 8.0 o superior
- NetBeans IDE (recomendado)

## 🚀 Instalación

1. Clonar el repositorio:
   ```bash
   git clone https://github.com/tu-usuario/gestion-concesionario.git
   ```

2. Configurar la base de datos:
   - Crear una base de datos MySQL llamada `concesionario`
   - Actualizar las credenciales en `src/main/resources/hibernate.cfg.xml`

3. Compilar el proyecto:
   ```bash
   mvn clean install
   ```

4. Ejecutar la aplicación:
   ```bash
   java -jar target/gestion-concesionario-1.0-SNAPSHOT-jar-with-dependencies.jar
   ```

## 👤 Credenciales por defecto

- Usuario: `admin`
- Contraseña: `admin`

## 📚 Documentación

La aplicación incluye:
- Manual de usuario en la carpeta `docs/`
- Documentación técnica generada con JavaDoc
- Comentarios en el código fuente

## 🎨 Interfaz de usuario

La aplicación implementa una interfaz moderna y accesible con:
- Más de 13 componentes Swing diferentes
- Atajos de teclado para todas las operaciones principales
- Tooltips informativos
- Alto contraste y textos escalables
- Compatibilidad con lectores de pantalla

## 📊 Reportes disponibles

- Inventario actual de vehículos
- Historial de ventas
- Ventas por vendedor
- Estadísticas mensuales/anuales

## 🔒 Seguridad

- Sistema de autenticación de usuarios
- Registro de operaciones por usuario
- Validación de datos en todos los formularios
- Protección contra inyección SQL (mediante Hibernate)

## 🤝 Contribuir

Las contribuciones son bienvenidas. Por favor:
1. Hacer fork del repositorio
2. Crear una rama para tu funcionalidad
3. Hacer commit de tus cambios
4. Crear un Pull Request

## 📝 Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo `LICENSE` para más detalles.

## ✨ Agradecimientos

- A los desarrolladores de las librerías utilizadas
- A la comunidad de Java y Swing
- A todos los contribuidores del proyecto

## 📞 Soporte

Para reportar bugs o solicitar nuevas funcionalidades, por favor crear un issue en el repositorio. 